package PracticePackage;

public class FindPrimeNumber {

	public void printThPrimeNumber(int number){
		
		
		char[] ch = String.valueOf(number).toCharArray();
		for(int i=0 ; i < ch.length ; i++){
			int flag = 0;
			if(ch[i] != '0' && ch[i] != '1'){
			for(int j=2 ;j<Character.getNumericValue(ch[i])/2 ; j++){				
				if(Character.getNumericValue(ch[i])%j == 0 ){
					flag = 1;
					break;
				}
			}
			if(flag == 0){
				System.out.print(ch[i] + " ");
			}			
			}
		}
	}
	
	public static void main(String[] ar){
		
		FindPrimeNumber fp = new FindPrimeNumber();
		
		fp.printThPrimeNumber(1029317);
		
	}
}