package PracticePackage;

public class Fibonacci {
	
	public void getTheFibonacciSeries(int number){
		
		int previous = 1;
		int next = 1;
		int fibonacci = 0;
		System.out.print(0+" ");
		for(int i = 1 ; i<number ; i++){
			if(i<=2){
			System.out.print(1+" ");
			}
			else{
				
				fibonacci = previous + next;
				previous = next;
				next = fibonacci;
				System.out.print(fibonacci + " ");
			}
		}	
	}
	
	public static void main(String[] ar){
		
		Fibonacci fb = new Fibonacci();
		fb.getTheFibonacciSeries(7);
		
	}
	
	

}
