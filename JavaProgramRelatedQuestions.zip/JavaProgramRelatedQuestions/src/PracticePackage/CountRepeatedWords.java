package PracticePackage;

import java.util.HashMap;
import java.util.LinkedHashMap;

public class CountRepeatedWords {
	
	public void countRepeatedChars(String str){
		char[] ch = str.toLowerCase().toCharArray();
		int count = 1;
		for(int i=0 ; i<ch.length ; i++){
			for( int j = i+1; j<ch.length; j++){
				
				if(ch[i] == ch[j]){
					
					count++;
					ch[j] = ' ';
				}
			}
			if(ch[i] != ' '){
				System.out.println("Character : " + ch[i] + " and the count is : " +count);
			}
			count =1;
		}	
	}
	
	public void countRepeatedWords(String [] str){
		
		int count =1;
		for(int i=0 ; i<str.length ; i++ ){
			for(int j=i+1 ; j<str.length ; j++ ){
			if(str[i].toLowerCase().equals(str[j].toLowerCase())){
				count++;
				str[j] = "";
			   }
			}
			if(str[i] != ""){
				System.out.println("The word : " + str[i] + " and the count : " + count);
				System.out.println("LowerCAse : " +str[i].toLowerCase());
			}
			count = 1;
		}
	}
	
	public void printTheDifferWords(String [] str1 , String [] str2){
		
		int count =0;
		for(int i=0 ; i<str1.length ;i++){			
			for(int j=0 ;j < str2.length ;j++){
				if(str1[i] == str2[j]){
					count = i;
					str2[j] = "";
				}				
			}
			str1[count] = "";
			try{
				if(str1[i] != ""){
					System.out.println("Differ Words in String Array 1 : " +str1[i]);	
				}
				
			}catch(Exception ArrayIndexOutOfBoundsException){
				
			}						
		}
		
		for(int k=0 ;k < str2.length ;k++){
		if(str2[k] != ""){
			System.out.println("Differ Words in String Array 2 : " +str2[k]);
		}
		}
		
		
	} 
	
	public void countRepeatedWordsUsingHashMap(String str){
		
		char [] ch = str.toLowerCase().toCharArray();
		HashMap<Character,Integer> charMap = new LinkedHashMap<Character,Integer>();		
		for(Character c : ch){
			if(charMap.containsKey(c)){
				charMap.put(c, charMap.get(c) + 1);
			}
			else {
				charMap.put(c, 1);
			}
		}
		System.out.println(charMap);
	}
	
	public static void main(String [] ar){
		String[] str1 = {"Today","is","Monday","Tuesday","ASDF","asjdfads"};
		String[] str2 = {"Monday","is","Monday","Wednesday","agdah"};
		String [] str = {"Abc","abc","def","Def","ghi","GHI","dEf"};
		CountRepeatedWords cr = new CountRepeatedWords();
		//cr.countRepeatedChars("AsadASdf");
		//cr.countRepeatedWords(str);
		//cr.countRepeatedWordsUsingHashMap("TestTheHashMapReapeatFunction");
		cr.printTheDifferWords(str1, str2);
	}

}
