package PracticePackage;

public class SwapValues {
	//a=2;b=3; // print a=3;b=2;
	
	public void swapTwoValues(int a, int b){
		
		a = a+b;
		b = a-b;
		a = a-b;
		
		System.out.println("a = " + a);
		System.out.println("b = " + b);
	}
	
	//a=3 , b= 7 , c=6 ; print a =7, b=6 ;c=3
	public void swapThreeValues(int a, int b, int c){
		
		a = a+b+c;
		c = a-(b+c);
		b = a-(b+c);
		a = a-(b+c);
		System.out.println("a = " + a);
		System.out.println("b = " + b);
		System.out.println("c = " + c);
	}
	
	public static void main(String[] ar){
		SwapValues sv = new SwapValues();
		sv.swapTwoValues(5, 8);
		sv.swapThreeValues(3, 7, 6);
	}

}
