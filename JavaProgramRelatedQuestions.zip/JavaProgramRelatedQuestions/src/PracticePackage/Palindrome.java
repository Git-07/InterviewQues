package PracticePackage;

public class Palindrome {

	public void findTheNumberIsPalindrome(int number){
		
		int palindrome =0;
		int temp = number;
		
		while(temp >0){
			int rem = temp%10;
			palindrome = palindrome*10 + rem;
			temp = temp/10;
		}	
		String message = (palindrome == number) ? "Number is palindrome" : "Number is not palindrome"; 	
		System.out.println(message);		
	}
		
	public void findTheStringIsPalindrome(String str){
		
		char [] ch = str.toCharArray();
		int flag = 0;
		for(int i=0 ; i <ch.length/2 ;i++){		
		if(ch[i] != ch[ch.length -1 -i]){			
			flag =1;
			break;
		  }
		}
		String message = (flag == 0) ? "String is palindrome" : "String is not palindrome";
		System.out.println(message);
	}
	
	public static void main(String [] ar){
		
		Palindrome p = new Palindrome();
		p.findTheNumberIsPalindrome(1001);
		p.findTheNumberIsPalindrome(10012);
		p.findTheStringIsPalindrome("asdsa");
		p.findTheStringIsPalindrome("asdsaf");
	}
	
}
