package PracticePackage;

public class ArmStrongNum {
	
	
	
	public String checkArmStrong(int num){
		
		String str = "Number is not ArmStrong";
		
		int temp = num;
		int sum = 0;
		while(temp > 0){
		int rem  = temp%10;	
		sum = sum + rem*rem*rem;		
		temp = temp/10;
		}
		if(sum == num){
			
			str = "Number is ArmStrong";
			
		}
		
		return str;
		
	}

	public static void main(String [] ar){
		
		ArmStrongNum an = new ArmStrongNum();
		System.out.println(an.checkArmStrong(134));
	}
}
