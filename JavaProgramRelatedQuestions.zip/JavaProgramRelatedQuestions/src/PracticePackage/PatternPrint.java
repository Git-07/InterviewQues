package PracticePackage;

public class PatternPrint {
	
	public void printNumberPyramidNumberAsPerRows(int row){
		
		int counter = 1;
		for(int r=1 ;r<=row; r++){
			
			for(int j = r ; j< row ; j++){
			
				System.out.print(" ");
			}
			
			for(int c=1 ; c<= r ; c++){
				
				System.out.print(counter++);
				if(c !=r){
					System.out.print(" ");
				}
			}
			System.out.println();
		}		
	}
	
	public void printNumberPyramidNumberPreRowNumPlusTwo(int row){
		
		int counter = 1;
		for(int r=1; r<= row ;r++){
			int count = r;
			
			if(count != row){
			for(int i = count ; i<= 2*row - count; i++){
				
				System.out.print(" ");
			}
			}
			for(int c=1; c<=2*count - 1 ; c++){
				
				System.out.print(counter++);
				System.out.print(" ");
			}
			
			System.out.println();
		}
		
	}
	
	public static void main(String [] ar){
		
		PatternPrint p = new PatternPrint();
		p.printNumberPyramidNumberAsPerRows(5);
		p.printNumberPyramidNumberPreRowNumPlusTwo(3);
		
	}
}
