package PracticePackage;

import java.util.Arrays;

public class RotatedVersions {
	
	public void twoStringsAreRotatedVer(String str1 , String str2){
	
		
		String st1 = sortString(str1);
		String st2 = sortString(str2);
		boolean bool = st1.equals(st2);
		if(bool == true){
			System.out.println("Strings are rotated version");
		}
		else {
			System.out.println("Strings are not rotated version");
		}
	}
	
	public void twoStringArraysAreRotatedVer(String [] str1 , String [] str2){
		
		String [] st1 = sortStringArray(str1);
		String [] st2 = sortStringArray(str2);
		boolean bool = Arrays.equals(st1, st2);
		if(bool == true){
			System.out.println("String arrays are rotated version");
		}
		else {
			System.out.println("String arrays are not rotated version");
		}
		
	}
	public String sortString(String str){
		
		
		char[] ch = str.toCharArray();		
		for(int i =0; i<ch.length ;i++){			
			for(int j = i+1 ; j<ch.length ; j++){
				if(ch[i] > ch[j]){
					char temp = ch[i];
					ch[i] = ch[j];
					ch[j] = temp;				
				} 
				
			}
		}	
		String string = new String(ch);
		return string;
	}
	public String[] sortStringArray(String [] str){
		
		for(int i =0; i<str.length ;i++){			
			for(int j = i+1 ; j<str.length ; j++){
				if(str[i].compareTo(str[j]) > 0){
					String temp = str[i];
					str[i] = str[j];
					str[j] = temp;				
				} 
				
			}
		}	

		return str;
	}
	
	public static void main(String [] ar){
		String[] str1 = {"Today","is","Monday","Monday"};
		String[] str2 = {"Monday","is","Monday","Today"};
		RotatedVersions rv = new RotatedVersions();
		rv.twoStringsAreRotatedVer("asdfgbnh", "bhgndfas");
		rv.twoStringArraysAreRotatedVer(str1, str2);
	}

}
