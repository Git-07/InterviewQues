package JavaCollections;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Set;
import java.util.Map.Entry;

public class HashMapToCountCharacters {
	
	
	public static void main(String [] ar){

	String sentence [] = {"Bangalore" , "Mysore", "Hubbli" , "Mangalore" , "Ooty" , "Bangalore" , "Mysore"};
	//char[] words = sentence.replace(" ", "").toCharArray();
	//String[] wordsInSentence = sentence.split("\\s+");

	String word2 = "asdfghasdfgaaahasdfgh";
	char[] ch = word2.toCharArray();

   HashMap<Character,Integer> charmap =  new LinkedHashMap<Character,Integer>();

	for(Character cha:ch)
	{

		if (charmap.containsKey(cha)) {
			charmap.put(cha, charmap.get(cha) + 1);
		} else {
			charmap.put(cha, 1);
			System.out.println(cha);
		}
				
	}
	
	System.out.println(charmap);
	Set<Character> mToS = charmap.keySet();
	//System.out.println(mToS);
	
	HashMap<String,Integer> strMap = new LinkedHashMap<String,Integer>();
	for(String str : sentence){
		
		if(strMap.containsKey(str)){
			strMap.put(str, strMap.get(str) + 1);
		}
		else {
			strMap.put(str, 1);
		}
	}
	//System.out.println(strMap);
}

}
