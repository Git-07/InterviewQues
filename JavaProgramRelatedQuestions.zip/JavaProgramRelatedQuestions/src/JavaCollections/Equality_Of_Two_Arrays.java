package JavaCollections;
import java.util.*;

public class Equality_Of_Two_Arrays { // This will take care for Jumbled Elements in Arrays as well
	
	
	private void privateMem(){
		
	}
	public static void main(String[] args){
		
		//to be done when dealing with String input or String Array
		String [] str1 = {"One", "One","Two","Three","Three","Four","Five","Five","Six"};
		String [] str2= {"One", "One","Two","Three","Three","Four","Five","Six","Five"};
		
		LinkedHashSet<String> set1 = new LinkedHashSet<String>(Arrays.asList(str1));
		LinkedHashSet<String> set2 = new LinkedHashSet<String>(Arrays.asList(str2));
		set1.removeAll(set2);
        if(set1.size() == 0 && str1.length == str2.length)
		{
			System.out.println("equal");
		}
		else if(str1.length != str2.length || set1.size()>0 ){
			
			System.out.println("not equal");
		}
		
		
		
		// other way of doing is sorting and using Array.equals method
	/*	String [] str1 = {"One", "One","Two","Three","Three","Four","Five","Five","Six"};
		String [] str2= {"One", "One","Two","Three","Three","Four","Five","Five","Six","seven"};
		Arrays.sort(str1);
		Arrays.sort(str2);
		if(Arrays.equals(str1,str2)){
			System.out.println("Arrays are equal");
		}
		else{
			System.out.println("Arrays are not equal");
		}
		*/
		int[] a = {1,2,3,4,7,8};
		int[] b = {1,3,4,7,8,2};
		Arrays.sort(a);
		Arrays.sort(b);
		Arrays.fill(a, 0, 3, 2);
		for(int i=0 ; i < a.length ; i++){
			System.out.print(a[i] + " ");
		}
		if(Arrays.equals(a, b)){
			System.out.println("Arrays are equal");
		}
		else{
			System.out.println("Arrays are not equal");
		}
		
}
}