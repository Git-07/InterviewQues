package JavaCollections;
import java.util.*;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Arrays;


// Using Arrays package which helps to convert an array to list without any looping(Array.asList(arrayName))
//Using LinkedHashSet removing duplicates.
//Insertion order is not erased or maintained
public class Remove_Duplicate_Elements_LinkedHashSet {
	
	
	 Remove_Duplicate_Elements_LinkedHashSet(int a , int c){
		
	}
	 Remove_Duplicate_Elements_LinkedHashSet(String s){
		
	}
	
	public static void main(String[] a){
		String b = "Mohit";	
		b ="Latwal";
		System.out.println(b);
		//Scanner scan = new Scanner(System.in);
		System.out.println("Enter the String");
		//String sentence = scan.next();
		String sentence = "Mohit mohit Latwal latwal Mohit latwal Latwal";
		String word[] = sentence.split("\\s+");
		String s = "Moon";
		String [] c = s.split("o");		
		for(int i =0 ;i<c.length ; i++){
			System.out.print(c[i]);
		}
		//Converting Arrays to ArrayList using Arrays.asList(String array)
		ArrayList<String> originalList = new ArrayList<String>(Arrays.asList(word));
	//	for(int i =0 ;i < ch.length ; i++){
	//		originalList.add(ch[i].toString().toLowerCase());
	//	}

		System.out.println((int)Math.round(Float.valueOf(12.5f))); // downcasting (int -> float) done externally
		System.out.println(Float.valueOf(12.23f));// auto upcasting (int -> float)
		System.out.println("Original list :" + originalList);
		LinkedHashSet<String> set = new LinkedHashSet<String>(originalList);
		System.out.println(set);
		//below is the conversion of set to ArrayList
		//List<String> listWithoutDuplicates = new ArrayList<String>(set);
		//System.out.println("After using Linked hash set");
		//System.out.println(listWithoutDuplicates);
		
}
}
