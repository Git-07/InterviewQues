package JavaCollections;
import java.util.*;
public class Find_Intersection_Of_Two_Arrays {
	
	public static void main(String[] a){
		
		String [] str1 = {"One", "One","Two","Three","Four","Five","Five","Six"};
		String [] str2= {"Three","Five","Ninr","One"};
	  // one way is traversing through both arrays and then finally creating HashSEt
		HashSet<String> set = new HashSet<String>();
        for(int i= 0; i < str1.length ;i ++){
    	   for(int j =0 ;j < str2.length ; j++){
    		   if(str1[i].equals(str2[j])){
    			   set.add(str1[i]);
    		   }    		  
    	   }
		}	
        System.out.println(set);        
		//Other way using retainAll() method
        //Using LinkedHashSet to retain the insertion order
		LinkedHashSet<String> set1 = new LinkedHashSet<String>(Arrays.asList(str1));
		System.out.println("from Set1 :" + set1);
		LinkedHashSet<String> set2 = new LinkedHashSet<String>(Arrays.asList(str2));
		System.out.println("from Set2 :" + set2);
		set1.retainAll(set2);	
		System.out.println(set1); 
		set2.removeAll(set1);
		System.out.println(set2); // uncommon or extra in Set 2 from Set1 
	}
}

