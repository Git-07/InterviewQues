package JavaCollections;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class HashCodePrint {

public static void main(String []  art){

Map<String,String> map = new HashMap<String,String>();

map.put("city","Bangalore");
map.put("state","Karantaka");
map.put("zip","560090");
map.put("zip","560");
map.put(null, null);
map.put(null, null);

 Set<String> key = map.keySet(); // Set of keys

 for(String str : key){
 
  int hash = key.hashCode();
  System.out.println(hash);
 }

}
}