package JavaCollections;

import java.util.Stack;

/*Parameters: The method does not take any parameters.

Return Value: This method returns the element present at the top of the stack and then removes it.

Exceptions: The method throws EmptyStackException is thrown if the stack is empty.*/

public class StackPushPop {

	
	
	public static void main(String[] ar){
	
		Stack<String> stck = new Stack<String>();
		stck.push("First");
		stck.push("Second");
		stck.push("Third");
		stck.push("Fourth");
		System.out.println(stck.pop());
		System.out.println(stck);
	}
}
