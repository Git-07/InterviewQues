package JavaCollections;


class ListNode{
	
	String val;
	ListNode nextNode;
	ListNode(String s){
		this.val = s;		
	}
	
	public void displayLinkedList(ListNode currentNode){
	
		if(currentNode != null){
			System.out.print(currentNode.val +"-->");
		}
	}
	
	public void insertAtPosition(ListNode head, int position, String value){
		
		ListNode newNode = new ListNode(value);
		ListNode previousNode = head;
		int count = 1;
		while(count < position -1){
			previousNode = previousNode.nextNode;
			count++;
		}
		ListNode currentNode = previousNode.nextNode; 
		newNode.nextNode = currentNode;
		previousNode.nextNode = newNode;

	}
	
}


public class SinglyLinkedListInsertion {
	
		
	public static void main(String [] ar){
		
		ListNode headNode = new ListNode("Head");
		ListNode secondNode = new ListNode("Second");
		ListNode thirdNode = new ListNode("Third");
		headNode.nextNode = secondNode;
		secondNode.nextNode = thirdNode;

		headNode.insertAtPosition(headNode, 2, "TestInsertion"); //Exception in thread "main" java.lang.NullPointerException if position
		//position >= 5
		while(headNode != null){
			headNode.displayLinkedList(headNode);
			headNode = headNode.nextNode;
	}
 }	
}
