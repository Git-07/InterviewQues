package JavaCollections;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map.Entry;
import java.util.*;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class HashMapUsage {
	static XSSFCell cell;
	static XSSFRow row;
	static String path = "D:\\Policies.xlsx";

	
public static void writeRequestToExcelData(HashMap<String,String> map) throws IOException{        
		InputStream input = new FileInputStream(path);
		XSSFWorkbook wb =  new XSSFWorkbook(input);
		XSSFSheet sheet;
		sheet = wb.getSheetAt(0);
		int  i = 0;
			Set<String> keyset = map.keySet();
			for(String key : keyset){
				row = sheet.createRow(i++);
				//row = sheet.getRow(i++);
				row.createCell(0).setCellValue(key);
				row.createCell(1).setCellValue(map.get(key));
			}
		FileOutputStream fileOut = new FileOutputStream(path);
		wb.write(fileOut);	
		fileOut.close();
		wb.close();
		
	}

public static void main(String[] ar) throws IOException{
  
	 HashMap<String,String> map = new HashMap<String, String>();
    map.put("TC_01", "Pass");
    map.put("TC_02", "Fail");
    map.put("TC_03", "Pass");
    map.put("TC_04", "Pass");
    map.put("TC_05", "Pass");
    map.put("TC_06", "Fail");
    map.put("TC_07", "Pass");
  // System.out.println("qjnqjwkjklqbqjlkbx");
	//writeRequestToExcelData(map);
	//Below is to iterate over hash map
    
	map.remove("TC_07");
	//1. Iterating over Map.entrySet() using advanced for loops
	//This method is most common and should be used if you need both map keys and values in the loop.
	//Below is the java program to demonstrate it.
	
	Set<Entry<String,String>> entry = map.entrySet(); // Set of Map Object that contains <K,V>
	//Point to not here in above step we have converted the map to Set now iterator can be used on it
	 // Using advanced for loop
	
// The set supports element removal, which removes the correspondingmapping from the map, via the Iterator.remove, 
	//Set.remove, removeAll, retainAll and clear operations. It does not support the add or addAll operations.	
	//entry.add("",""); 
/*	for(Entry<String, String> e : entry){
		System.out.println("Key : " + e.getKey());
		System.out.println("Value : " + e.getValue());
	}
*/
	
	
	//2. Iterating over keys or values using keySet() and values() methods 
	//Map.keySet() method returns a Set view of the keys contained in this map and Map.values() method returns a collection-view of the values contained in this map.
	//So If you need only keys or values from the map, you can iterate over keySet or values using for-each loops. Below is the java program to demonstrate it.
/*  Set<String> key = map.keySet(); // Set of keys
  for(String str : key){
	  
	  System.out.println("key : " + key);  //set-view
	  
  }
  Collection<String> val =  map.values(); //Collection of values
  for(String str : val ){
	  System.out.println("values : " + val); //collection-view
 
	*/
	
	//setViewOfKV --> this is nothing but the <K,V> data backet of Type Entry<K,V> 
	
	//3. Iterating using iterators over Map.Entry<K, V> 
	/*Set<Entry<String,String>> setViewOfKV = map.entrySet(); // here it is a set. So which will be iterated now using Iterator
	System.out.println(setViewOfKV); //[TC_06=Fail, TC_05=Pass, TC_04=Pass, TC_03=Pass, TC_02=Fail, TC_01=Pass]
	Iterator<Entry<String,String>> itr = setViewOfKV.iterator();
      while(itr.hasNext()){
		 
    	 Entry <String,String> kv = itr.next();		
    	 System.out.println("Key : " + kv.getKey());
    	 System.out.println("Val : " + kv.getValue());
		
		
	}*/
	
	//4.Map.forEach(action) method and using lambda expression. Note: forEach method introduced in 1.8
    map.forEach(
    		(k,v) -> 
    		{
    		System.out.println("Key : " + k);
    		System.out.println("val : " + v);
    		}
    		);
	
	System.out.println("done");
	List<String> al = new ArrayList<String>();
	LinkedHashSet<String> lhs = new LinkedHashSet<String>();
   lhs.add("ASDFGGHH");
	String [] ars = {"","","",""};

	lhs.forEach(
			(k) ->
			{
				System.out.println("What is in LHS : " + k);
				
			}
			);
}



}
