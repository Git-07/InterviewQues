package JavaCollections;
import java.util.*;
//Using HashSet removing duplicates.
//Insertion order is erased not maintained
public class Remove_Duplicate_Elements_HashSet {
	public static void main(String[] a){		
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the String");
		//String sentence = scan.next();
		String sentence = "ABCD Mohit mohit Mohit Latwal Latwal Latwal latwal";
		String ch[] = sentence.split(" ");
	/*	ArrayList<String> originalList = new ArrayList<String>();
		for(int i =0 ;i < ch.length ; i++){
			originalList.add(ch[i].toString());
		} */
	//	System.out.println("Original sentence"+ originalList);
		//HashSet<String> set = new HashSet<String>(originalList);
		Set<String> set = new HashSet<String>(Arrays.asList(ch)); // .asList(Arguments should be String [])
		System.out.print(set);
/*		SortedSet<String> tree = new TreeSet<String>(Arrays.asList(ch));
		tree.last();*/
		//Converting the list to array is simple use .toArray()method. For e.g. list.toArray()
		//covert HAshSet to ArrayList
	/*	ArrayList<String> listWithoutDuplicates = new ArrayList<String>(set);		
		System.out.println(listWithoutDuplicates); */
		//the duplicates in the Sentence
      
	}
}
