package Same_Array_Pattern;

public class PrintNotMatching {
	
	//Print unique or which are not duplicates
	
	public static void main(String [] ar){
	String s  =  "asdfasdfgz"; 
	char ch [] = s.toCharArray();
	int flag = 0;
	for(int i =0 ; i < ch.length ; i++){
		
		for(int j = i+1 ; j <ch.length ; j++ ){
			
			if(ch[i] == ch[j]){
				
				ch[j] = ' ';
				flag = 1;
			}			
		}
	//Print only matching		
	/* if(ch[i] != ' ' && flag == 1){
		System.out.print(ch[i]); 
	 }*/	
	 
	//Print only not matching
     if(ch[i] != ' ' && flag != 1){
	     System.out.print(ch[i]); 
			 }	
		//Print only once
		/*  if(ch[i] != ' '){
			     System.out.print(ch[i]); 
					 }	*/
	flag = 0;						
	}
	
	}

}
