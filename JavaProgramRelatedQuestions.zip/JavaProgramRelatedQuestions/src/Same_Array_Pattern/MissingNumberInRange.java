package Same_Array_Pattern;

public class MissingNumberInRange {

	public static void main(String[] ar) {

		int[] numbers = {12, 13, 14, 7, 8, 9 };
		int num = 10;
		

		for (int j = 1; j <= num; j++) {
			int flag = 0;
			for (int i = 0; i < numbers.length; i++) {

				if (numbers[i] == j) {
					flag = 1;
					break;
				}

			}
			if (flag == 0) {
				System.out.print(j + " ");
			}
		}
	}

}
