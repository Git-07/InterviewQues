package Same_Array_Pattern;

public class ShiftAParticularNumber {
	
	public static void main(String [] ar){

		
		String num = "120304020";
		char [] numbers = num.toCharArray();
		int zeroCounter = 0;
		
		for(int i=0 ; i< numbers.length ;i++){
			int flag = 0;   
		   if(numbers[i] == '0'){
		    ++zeroCounter;  
		    flag = 1;
		 }		 

		if(flag == 0){
		System.out.print(numbers[i]);
		}
	}

		for(int i= zeroCounter; i< numbers.length; i++){
		System.out.print("0");
		}

	}
}
