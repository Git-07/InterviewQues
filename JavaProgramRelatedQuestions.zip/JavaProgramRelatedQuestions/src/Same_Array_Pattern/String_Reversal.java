package Same_Array_Pattern;

public class String_Reversal {
	
	public static void main(String[] ar){
	
		String words = "Today is Monday";
		String[] word = words.split("\\s+");
		for(int i = word.length -1 ; i>=0 ; i--){
			
			System.out.print(word[i] + " ");
		}
	}

}
