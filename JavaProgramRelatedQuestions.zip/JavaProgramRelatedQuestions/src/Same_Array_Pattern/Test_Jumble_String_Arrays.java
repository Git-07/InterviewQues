package Same_Array_Pattern;
public class Test_Jumble_String_Arrays { // Another version of Anagram(Jumbled data)
	public static void main(String[] ar) {
		int temp = 0 ; int counter1 = 0; int counter2 = 1;
		String[] str1 = { "Monday", "Wed", "Monday"};String[] str2 = { "Monday", "Monday", "Wed" };
		if (str1.length != str2.length) {
			System.out.println("String arrays are not equal");
		}
		else if (str1.length == str2.length) {
			for (int i = 0; i < str1.length; i++) {
				int flag = 0;
				counter2 = 1;counter1 = 0;
				for (int j = 0; j < str2.length; j++) {
					if (str1[i] == str2[j]) {
						flag = 1;counter1++;
					}
				}
				for (int k = 0; k < str1.length; k++) {
					if (str1[i] == str1[k] && i != k) {
						counter2++;
					}
				}
				temp = flag;
				if (temp == 0 || counter1 != counter2) {
					break;
				}
			}
			if (temp == 1 && counter1 == counter2) {
				System.out.println("String arrays are equal or are rotated versions");

			} else if (temp == 0 || counter1 != counter2) {
				System.out.println("String arrays are not equal or are not rotated verisons");
			}
		}
	}
}
