package Same_Array_Pattern;

public class String_ObjectCreation {
	
	public static void main(String[] arg){
		
	String s1 = "Welcome"; // String literal reference
	String s2 = "Welcome"; // String literal reference
	if(s1 == s2){
		System.out.println("both references are same");		
	}
	if(s1.equals(s2)){
			System.out.println("both content are same");
		}
	
	String s3 = "Test the String Object creation"; // String literal object reference
	String s4 = new String("Test the String Object creation"); // String Class object reference
	if(s3 == s4){
		System.out.println("both s3 and s4 references are same");
	}
	if(s3.equals(s4)){
		System.out.println("both s3 and s4 contents are equal");
	}
}
}
