package Same_Array_Pattern;

public class Sort_String_Descending_Order {
	
	static String str = "aaaaqqwzedh";	
	static char temp;
//Sort the String in descending Order 
	public static void main(String[] ar){
	char[] ch = str.toCharArray();
	for(int i =0; i<ch.length ;i++){	
		for(int j = i+1 ; j<ch.length ; j++){			
			if((int) ch[i] < (int)ch[j]){
				temp = ch[j];
				ch[j] = ch[i];
				ch[i] = temp;				
			} 
			
		}
	}	
	//System.out.print(str.valueOf(ch));
	for(int k=0 ; k< ch.length ; k++){
		System.out.print(ch[k]);
	}
	//System.out.print((char) 65);
}

}
