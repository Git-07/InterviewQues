package Same_Array_Pattern;

public class AsteriskTrianglePrinting {

	public static void main(String [] ar){
		
		/*
	*
   ***
  *****
 *******
*********
 
		 */
	

		int number =5;
		for(int i = 1 ; i<= number ; i++){

		int count = i;
		int space = number - count;

		   for(int s =0 ; s < space ; s ++){

		     System.out.print(" ");
		 
		  }
		  
		  for( int j = 1; j <= 2*count -1 ; j++){
		   
		  System.out.print("*");
		  }

		System.out.println();
		}
	
	
	/*
    *
   * *
  * * *
 * * * *
* * * * *

	 */
	
	int num = 5;
	
	for(int k = 1 ; k<=num ; k++){
		
		int count = k;
		int space = num - count;
		
		for(int l = 0 ; l< space ;l++){
			
			System.out.print(" ");
			
		}
		
		for(int m =1; m <=count; m++){
			
			System.out.print("*");
			System.out.print(" ");
		}
		
		System.out.println();
		
	}
	
	
}
}