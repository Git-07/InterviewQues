package Same_Array_Pattern;

public class Attach_To_Pattern {
	
	public static void main(String[] ar){
		
		String name = "Mohit";
		char nameChars[] = name.toCharArray();
		int counter = 0 ; 		
		for(int i = 0; i< nameChars.length ; i++){			
        switch(nameChars[i]){
        
        case 'a' : 
             if(nameChars[i] == 'a'){
            	 counter = i;
            	 break;
             }
        case 'e' : 
            if(nameChars[i] == 'e'){
           	 counter = i;
           	break;
            }
        case 'i' : 
            if(nameChars[i] == 'i'){
           	 counter = i;
           	break;
            }
        case 'o' : 
            if(nameChars[i] == 'o'){
           	 counter = i;
           	break;
            }
        case 'u' : 
            if(nameChars[i] == 'u'){
           	 counter = i;             
            }                       
          }
        if(counter >=1){
        	break;
        }
      }	
		for(int j = counter; j<nameChars.length; j++){
			
			System.out.print(nameChars[j]); 
			
		}
		for(int k = 0 ; k<counter ;k++){
			System.out.print(nameChars[k]);
		}
		System.out.print("ay");
	
		
		
		
	}

}
