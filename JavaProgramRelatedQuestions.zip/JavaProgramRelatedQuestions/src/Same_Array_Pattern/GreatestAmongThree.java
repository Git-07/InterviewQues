package Same_Array_Pattern;

import java.util.Arrays;

public class GreatestAmongThree {
	
	public static void main(String[] ar){
		int [] num = {2,6,9,12,19};
		
		for(int i = 0 ; i< num.length ; i++){
		  for(int j = i+1 ;j < num.length ;j++){
			 int temp = num[j];
			   if(num[i] < num[j]){
			  num[j] = num[i];
			  num[i] = temp;
			 }
			}
			
		}
		for(int i =0 ; i< num.length ; i++){
		System.out.println(num[i]);
		}
		
		Arrays.sort(num);
		System.out.println(num[2]); // Third Highest
		
	}

}
