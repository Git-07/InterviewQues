package Same_Array_Pattern;

public class CicularOrderPrint {

	public static void main(String[] args){	
	String str ="factset";
	char[] ch = str.toCharArray();
	int k = 0; 
	int i = 0;
	while(i < ch.length){
		
		for(int j = i+1; j< ch.length ; j++){
			
			System.out.print(ch[j]);
		}
		i++;
		k = i;
		for(int l = 0 ; l< k ; l++){
			System.out.print(ch[l]);
		}
		System.out.println();
	}
	
	for(char s :ch){ // advanced for loop
		
	}
}
}
