package Same_Array_Pattern;

public class SwapTwoStrings {
	
	public static void main(String [] ar){
		
		String a = "Hello";
		String b = "World";
		
		/*a = a + b;
		b = a.substring(0,a.length() - b.length());
		System.out.println("b is : " +b);
	    a = a.substring(b.length());
		System.out.println("a is : " + a);*/
		a = b + " " + a;
		b = a.split(" ")[1];
		a = a.split(" ")[0];
		System.out.println("a value is now : " + a);
		System.out.println("b value is now : " + b);
		
	}

}
