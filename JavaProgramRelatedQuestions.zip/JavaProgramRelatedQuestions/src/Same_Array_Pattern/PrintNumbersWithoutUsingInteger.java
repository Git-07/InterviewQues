package Same_Array_Pattern;

public class PrintNumbersWithoutUsingInteger {
	
	public static void main(String [] ar){
		
		String a = "ABCDE";
		String b = "ABCD";
		for(int i = a.length() - b.length(); i <= a.length()*a.length()*b.length() ;i++){
			
			System.out.println(i);
		}
		
		
	}

}
