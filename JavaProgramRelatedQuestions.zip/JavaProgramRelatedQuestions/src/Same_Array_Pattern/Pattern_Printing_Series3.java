package Same_Array_Pattern;

public class Pattern_Printing_Series3 {
	
	static int counter = 1;
	static int row = 4;
	public static void main(String[] ar){

		for(int r =1; r<=row ;r++){
			
			int count = r;
			
			for(int i =1; i<=2*row - 2*count ;i++){
				
				if( count != row && count != row -1){
				System.out.print(" ");
				}
			}
			if( count == row -1){
				System.out.print("   ");
				}
			
				for(int c =1; c<= 2*count - 1; c++){
					System.out.print(counter++);
					System.out.print(" ");
										
				}
	
			System.out.println();
	}		
 }
}
