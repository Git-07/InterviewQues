package Same_Array_Pattern;

public class Pattern_Printing_Series3_ExtendedFurther {


	
	static int counter = 1;
	static int row = 5;
	
	static void enterSpace(int count){
		
		for(int i= 0 ; i< count ; i++){
			System.out.print(" ");
		}
	}
	public static void main(String[] ar){
        
		//System.out.println(flag);
		int rule = 0;
		for(int r =1; r<=row ;r++){
			
			int count = r;
			//if(count != row){
            /*   if(count <= 3){
				rule = 4*row - (3*count + count - 1);
               }
               else if(count  > 3 && count <= 10){*/
              rule = 4*row - (3*count + count) ;
            //   }
             /* else if(count  >10 && count <= 31){
               rule = 4*row - (3*count + count);
               }*/
               for(int j =1; j<= rule ; j++){
					
				System.out.print(" ");
					
               }
			
			//	for(int i = 1 ; i<= 3*row - (2*count  + count-1); i++){ ---> this is for under 100
                		//for(int i = 1 ; i<= 4*row - (3*count  + count-2); i++){// ---> this is for under 1000
            /*	  for(int i = 1 ; i<= 4*row - (3*count  + count-1); i++){ 
					
					System.out.print(" ");
					
				}*/
			//}
		/*	else if(count  > 3 && count != row){
				
				for(int j =1; j<= 3*row - 3*(count) ; j++){
					
					//if( count != row && count != row -1){
					System.out.print(" ");
					}
				}*/
             /*	else if(count  > 3 && count <= 10){
    				
    				//for(int j =1; j<= 3*row - (2*count + count) ; j++){ ---> this is for under 100
             		//for(int j =1; j<= 4*row - (3*count + count - 1) ; j++){//----> this is for under 1000
             		for(int j =1; j<= 4*row - (3*count + count - 1) ; j++){ 
    					//if( count != row && count != row -1){
    					System.out.print(" ");
    					}
    				}*/
	               /*  else if(count  >10 && count < 100){
    				
    				//for(int j =1; j<= 3*row - (2*count + count) ; j++){
             		for(int j =1; j<= 4*row - (3*count + count) ; j++){
    					
    					//if( count != row && count != row -1){
    					System.out.print(" ");
    					}
    				}
			}*/
			
		/*	else if( count != row && count != row -1){
				for(int i =1; i<=2*row - 2*count ;i++){
	
					System.out.print(" ");
	
				}
			}*/
			
				for(int c =1; c<= 2*count - 1; c++){				
					System.out.print(counter++);
					
					if( count <= 3 ){
					System.out.print("   ");
					}
					else if(count > 3){
						System.out.print("  ");
					}
					
				/*	else {
						System.out.print(" ");
					}*/
				/*	if(counter <= 10){
						
					}
					else {
						System.out.print(" ");
					}*/
			/*		int newFlag = 0;
						int temp = counter;						
						while(temp > 0){
							
							temp = temp/10;
							newFlag ++;
						}
						 if(flag-newFlag == 0){
								//System.out.print(" ");
							   enterSpace(flag-1);
							}
						 else if(flag > newFlag){
							 //enterSpace(flag +1);
							enterSpace(flag + 1 - newFlag);							
						 }*/
					
	                  
					/*	if( count <= 3 ){
							System.out.print("   ");
							}
							else if(count <=10 && count > 3 && counter <100){
								System.out.print("  ");
							}
							
							else {
								System.out.print(" ");
							}*/
				//	}
					
					
				}
	
			System.out.println();
	}		
		}}
	

