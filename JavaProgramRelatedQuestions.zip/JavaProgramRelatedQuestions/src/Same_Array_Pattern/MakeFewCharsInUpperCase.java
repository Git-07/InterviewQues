package Same_Array_Pattern;

public class MakeFewCharsInUpperCase {

	public static void main(String [] ar){
		
		String str = "mohit latwal";
		
		char [] ch = str.toCharArray();
		for(int i = 0 ; i < ch.length ; i++){
			
			if(ch[i] == 'm'){
			
				ch[i] = 'M';
				
			}	
		  if (ch[i] == 'l' && ch[i-1] == ' '){
			
			  ch[i] = 'L';
				
			}
		}
		System.out.println(str.substring(0, 7));
	System.out.println(ch);	
	}
}
