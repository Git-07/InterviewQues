package Same_Array_Pattern;

public class Filter_Prime_Number {

	public static void main(String[] ar) {

		int num[] = {0,1, 2, 8, 1, 6, 11, 2, 2, 2, 2, 8, 13, 19, 4, 26, 4, 4, 4, 0, 27, 3, 91 };
		for (int i = 0; i < num.length; i++) {
			if (num[i] != 0 && num[i] != 1) {
				int flag = 0;
				for (int j = 2; j <= num[i] / 2; j++) {
					if (num[i] % j == 0) {
						flag = 1;
						break;
					}
				}
				if (flag == 0) {
					System.out.print(num[i] + " ");
				}
			}
		}
	}
}
