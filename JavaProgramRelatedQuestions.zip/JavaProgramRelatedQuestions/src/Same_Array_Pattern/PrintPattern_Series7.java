package Same_Array_Pattern;

public class PrintPattern_Series7 {
	public static void main(String[] args){	 	 
		int row = 10;
		 for( int r=1; r<=row; r++){
			 int count = r;			 
			 for(int i = 1; i<=2*row-2*count; i++){
				 System.out.print(" ");
			 
			 }
				 for(int c=1;c<=count;c++){
					 System.out.print(c);
					 System.out.print(" ");
				 }
				 for(int c=count-1;c>=1;c--){
					 System.out.print(c);
					 System.out.print(" ");
				 }

			 System.out.println(); 
			 

		 }
	   	
	}

}
