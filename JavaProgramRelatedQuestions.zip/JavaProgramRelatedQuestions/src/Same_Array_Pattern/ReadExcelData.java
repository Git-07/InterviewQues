package Same_Array_Pattern;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcelData {
	
	String data = "";
	boolean booleanValue;
	int numericValue;
	
	public static void main(String [] ar) throws IOException{
		
		ReadExcelData exceldata = new ReadExcelData();
		
		String value1 = exceldata.getExcelData("TC_02", 0, "ControlNumbers", "C://Users//mohit//Desktop//Test_BL_TestNG//Test_Data_BLRegression.xlsx");
		System.out.println("The value read from excel is : " + value1);
		String value2 = exceldata.getExcelData("TC_02", 0, "TestCaseExecute", "C://Users//mohit//Desktop//Test_BL_TestNG//Test_Data_BLRegression.xlsx");
		System.out.println("The value read from excel is : " + value2);
	}
	
	
	public void setTheBooleanValue(boolean bool){
		
		booleanValue = bool;
	}
	
	public String getTheBooleanValue(){
		
		return String.valueOf(booleanValue);
	}
	
	public void setTheNumericValue(int number){
		
		numericValue = number;
	}
	
	public String getTheNumericValue(){
		
		return String.valueOf(numericValue);
	}
		
	public String getExcelData(String testCaseId,int sheetIndex, String colName, String path) throws IOException{
		int colIndex = -1;
		InputStream input = new FileInputStream(path);
		XSSFWorkbook wb = new XSSFWorkbook(input);
		XSSFSheet sheet = wb.getSheetAt(sheetIndex);
		
		Iterator<Row> rows = sheet.rowIterator();
		
		while(rows.hasNext()){
			XSSFRow row = (XSSFRow) rows.next();
			
			if(row.getRowNum() == 0){
				
			Iterator<Cell> cells = row.cellIterator();
			
			while(cells.hasNext()){
			
				XSSFCell cell = (XSSFCell) cells.next();
				
				if(cell.getStringCellValue().contentEquals(colName)){
					
					colIndex = cell.getColumnIndex();
					
				}		
			}
		}			
			else if(row.getRowNum() != 0){
				
				Iterator<Cell> cells =  row.cellIterator();
				
				while(cells.hasNext()){
					
					XSSFCell cell = (XSSFCell) cells.next();
					
					if(cell.getStringCellValue().contains(testCaseId)){
						
						while(cell.getColumnIndex() != colIndex){
							
							cell = (XSSFCell) cells.next();
							
						}
          			switch(cell.getCellTypeEnum()){
						case BLANK:
							data = "";
							break;
						case BOOLEAN:
							setTheBooleanValue(cell.getBooleanCellValue());
							data = getTheBooleanValue();
							break;
						case ERROR:
							data = "";
							break;
						case FORMULA:
							break;
						case NUMERIC:
							setTheNumericValue((int) cell.getNumericCellValue());
							data = getTheNumericValue();
							break;
						case STRING:							
							data = cell.getStringCellValue();
							break;
						case _NONE:
							break;
						default:
							data ="";
						
						}					
						
					}
				}				
			}
		}
		wb.close();
		return data;		
	}
}
