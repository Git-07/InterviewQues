package Same_Array_Pattern;

public class RemoveOneCharInRepeatedChar {
	
	//out of consecutive two matching chars print only one	
	public static void main(String [] ar){	
		
	String str = "Treeewwwqe";
	char [] ch = str.toCharArray();

	 for(int i = 0 ; i < ch.length ; i++){
	 
	  int j = i+1;
	    
	    try {
	      if(ch[i] == ch[j] && j!=ch.length){

	         ch[j] = ' ';           
	        
	        }
	      if(ch[i] != ' '){
		       
		       System.out.print(ch[i] +"");
		      
		     }    
		  
	    }catch(ArrayIndexOutOfBoundsException e){
	    	
	    } 
	     
	  }

	if( ch[ch.length - 2] != ch[ch.length - 1]){ //ch[ch.length - 2] == ch[ch.length - 1] ||

	System.out.print(ch[ch.length - 1]);

	}
	 
	  }

	}

