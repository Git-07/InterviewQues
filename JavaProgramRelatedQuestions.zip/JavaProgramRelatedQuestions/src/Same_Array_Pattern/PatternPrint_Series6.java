package Same_Array_Pattern;

public class PatternPrint_Series6 {

	public static void main(String[] ar) {


			int n = 6;		
			for(int i = 1 ;i<=n;i++){
				int count = i;
				if(i%2 == 0){
				System.out.print(++count);
				}
				for(int j =1; j<=3; j++){
				System.out.print(i);
				}
				if(i%2 !=0){
				System.out.print(++count);
				}
				System.out.println();
			}	
	}

}
