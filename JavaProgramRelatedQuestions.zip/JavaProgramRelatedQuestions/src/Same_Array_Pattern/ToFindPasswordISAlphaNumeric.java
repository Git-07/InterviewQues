package Same_Array_Pattern;

public class ToFindPasswordISAlphaNumeric {
	
	//Find the password is alpha numeric and having length in between 8 to 19
	public static void main(String [] ar){
		
		String str = "aaa12223ASDFabc22aa";
		String  alphaNumReg = "^[a-zA-Z0-9]{8,19}";	
		if(str.matches(alphaNumReg)){
			
			System.out.println("Password contains alpha num and the length is : " + str.length());
		}
		
		String smallAlphaReg = ".*[a-z].*";
		String numReg = ".*[0-9].*";
		String capAlphaReg = ".*[A-Z].*";
		
		if(str.matches(numReg) && str.matches(capAlphaReg) && str.matches(smallAlphaReg) && str.length() >= 8 && str.length() <= 19 ){
			
			System.out.println("Password contains alpha num");
			
		}
	}
}
