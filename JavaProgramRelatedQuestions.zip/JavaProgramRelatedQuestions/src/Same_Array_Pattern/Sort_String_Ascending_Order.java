package Same_Array_Pattern;

public class Sort_String_Ascending_Order {
	
	static String str = "azedh";	
	static char temp;
//Sort the String in Ascending Order 
	public static void main(String[] ar){
	char[] ch = str.toCharArray();
	for(int i =0; i<ch.length ;i++){		
		for(int j = i+1 ; j<ch.length ; j++){
			if( ch[i] > ch[j]){
				temp = ch[i];
				ch[i] = ch[j];
				ch[j] = temp;				
			} 		
		}
	}	
	//System.out.print(str.valueOf(ch));
	for(int k=0 ; k< ch.length ; k++){
		System.out.print(ch[k]);
	}
	//System.out.print((char) 65);
}

}
