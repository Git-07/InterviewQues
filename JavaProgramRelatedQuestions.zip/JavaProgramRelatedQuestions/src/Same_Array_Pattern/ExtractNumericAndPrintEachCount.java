package Same_Array_Pattern;

public class ExtractNumericAndPrintEachCount {
	
	public static void main(String ar[]){
		
		String str = "@!$!@$679999196347%%";
		char[] chars = str.toCharArray();
		int counter = 1;
		for(int i = 0; i<chars.length ; i++){
			if(Character.isDigit(chars[i])){
				for(int  j= i+1 ;j<chars.length ; j++){
					if(chars[i] == chars[j]){
						chars[j] = ' ';
						++counter;
					}
				}
				if(chars[i] != ' '){
				System.out.println("count of " + chars[i] + " = " + counter);
				}
				counter = 1;
			}
			
		}
		
	}

}
