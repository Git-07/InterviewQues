package Same_Array_Pattern;

public class Palindrome_String {

	public static void checkStringIsPalindrome(String str) {

		char[] ch = str.toCharArray();
		int flag = 0;
		for (int i = 0; i < ch.length / 2; i++) {

			if (ch[i] != ch[ch.length - 1 - i]) {

				flag = 1;
				break;

			}
		}

		String message = (flag == 0) ? "String is palindrome" : "String is not palindrome";
		System.out.println(message);
	}

	public static void main(String args[]) {

		checkStringIsPalindrome("asdssa");
	}

}
