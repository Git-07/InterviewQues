package Same_Array_Pattern;

//In number theory, a perfect number is a positive integer that is equal to the sum of its positive divisors,

public class Perfect_Number {

	public static void checkNumIsPerfect(int number) {

		int sum = 1;

		for (int i = 2; i <= number / 2; i++) {

			if (number % i == 0) {

				sum = sum + i;

			}

		}

		String message = (sum == number && sum != 1) ? "Number is perfect" : "Number is not perfect";
		System.out.println(message);
	}

	public static void main(String args[]) {

		checkNumIsPerfect(6);
	}
}
