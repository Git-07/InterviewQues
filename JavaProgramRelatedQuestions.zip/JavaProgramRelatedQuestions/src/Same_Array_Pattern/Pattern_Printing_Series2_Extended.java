package Same_Array_Pattern;

public class Pattern_Printing_Series2_Extended {
	
	//REfer to notepad
	public static void main(String[] arg){
		
		  int row = 5;
		  int counter  = 1;
		  for(int r = 1; r<=row ; r++){
		
			int count = r;
			//if(count != row){
			int rule = 0;
			//rule will be changed as per the row count is changed need to follow this design approach across the number 
			//pyramid program
			/*if(count <= 4){
				
				rule = 2*row -2*(count-1) - 1;
			}
		    else if(count >= 5 && count <= 13){*/
			   
			rule = 2*row -2*count;
				
		   // }
		 /*   else if(count > 13){
		    	
		    	rule = 2*row - 2*count + 1;
		    }*/
		   // for(int i = 1 ; i <=2*row -2*(count-1) - 1 ; i++){
			for(int i = 1 ; i <= rule ; i++){
		    	System.out.print(" ");
		    }
			//}
		    for(int j = 1; j<=count; j++){
		    	System.out.print(counter++);
		    	
		    	if( count <= 4){
					System.out.print("   ");
					}
					else if(count > 4){
						System.out.print("  ");
					}
					
		    	/*int newFlag = 0;
		    	int temp = counter;						
				while(temp > 0){
					
					temp = temp/10;
					newFlag ++;
				}
				 if(flag-newFlag == 0){
					 enterSpace(flag);
						//System.out.print("  ");
					}
				 else if(flag > newFlag){							
					 enterSpace(flag + 1);					 
				 }*/
		    	
		    }
		    
		    System.out.println();
		 }
	}

}
