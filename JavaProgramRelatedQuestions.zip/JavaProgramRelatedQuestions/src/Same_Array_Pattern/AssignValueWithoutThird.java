package Same_Array_Pattern;
public class AssignValueWithoutThird extends Thread{
	public static void main(String[] s) throws Throwable {
		AssignValueWithoutThird t = new AssignValueWithoutThird();
		//Target : Print y =x; x = z and z =y;

		//t.finalize();
/*		int x = 2;
		int y = 7;
		long a = 10;
		x = x + y;
		y = x - y;
		x = x - y;
		System.out.println(x);
		System.out.println(y);
		System.out.println(a);*/
		int x = 2;
		int y = 4;
		int z = 10;
		
	/*	x = x+y+z; // 16
		y = x -(y+z); // 2
		z = x - (y+z); // 4
		x = x - (y+z);//10

		System.out.println("x : " +x);
		System.out.println("y : " +y);
		System.out.println("z : " +z);*/

	
		//t.run();
		
		//Target : Print y = z; x = y and z =x;
		x = x+y+z;
		z = x - (y+z); // 2
		y = x - (y+z) ; // 10
		x = x - (y+z); //4
		
		System.out.println("x : " +x);
		System.out.println("y : " +y);
		System.out.println("z : " +z);

	}

/*	static {

		System.out.println("ndlknadvlk");
	}

	static {
		System.out.println("execute this 1st");
	}*/
}
