package Same_Array_Pattern;

public class CountOf3ContinuousChars {
	
	public static void getTheCountOfTriplets(String str){
		
		char [] ch = str.toCharArray();
		int counter = 1;
		int flag = 0;
		for(int i=0 ; i< ch.length ; i++){
			
		 int j=i+1;
		 try{
		 if(ch[i] == ch[j] && j< ch.length){
			 
			 counter++;
		 }
		 else {
			 counter = 1;
		 }
		 }catch(ArrayIndexOutOfBoundsException e){}
		 if(counter == 3){
			 flag ++;
			 --counter;
		 }
		}
		System.out.println(flag);
		
		
	} 
	
	public static void main(String [] ar){
		
		getTheCountOfTriplets("aaaadddgghhaaaa");
		
	}	

}


/*static int setTheCount;
public static void getTheRepeatedSetCount(String str){
char [] ch = str.toCharArray();
int counter = 1;
int flag =0;
for(int i=0 ;i<ch.length ; i++){

int j = i+1;
try{
   if(ch[i] == ch[j] && j < ch.length){
    ++counter;   
   }

else {
counter =1;  
}
}catch(ArrayIndexOutOfBoundsException e)   {}
  if(counter == setTheCount){
  ++flag;
  --counter;
 }

}

System.out.println(flag);
}

public static void main(String [] ar){

setTheCount = 2;
getTheRepeatedSetCount("aaaabbb");

}*/
