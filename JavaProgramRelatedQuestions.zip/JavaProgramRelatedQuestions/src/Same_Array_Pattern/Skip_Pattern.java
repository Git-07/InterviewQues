package Same_Array_Pattern;
import java.util.*;
public class Skip_Pattern {

	//static StringBuffer str = new StringBuffer("AutoPolicy.dataOrderList.[2].DataOrder.subjectList.[0].Driver.ClientPortfolio.ClientPortfolioSearchInfo.Person.ContactInfo.contactPointList.[0].Address.city�");
	
	//static String str = "AutoPolicy.dataOrderList.[2].DataOrder.subjectList.[0].Driver.ClientPortfolio.ClientPortfolioSearchInfo.Person.ContactInfo.contactPointList.[0].Address.city�";
	//str = "AutoPolicy.dataOrderList.[2].DataOrder.subjectList.[0].Driver.ClientPortfolio.ClientPortfolioSearchInfo.Person.ContactInfo.contactPointList.[0].Address.city�";
	
 public static void main(String[] ar){
	 String str = "AutoPolicy.dataOrderList.[2].DataOrder.subjectList.[0].Driver.ClientPortfolio.ClientPortfolioSearchInfo.Person.ContactInfo.contactPointList.[9].Address.city�";
	 //char [] regex = {'[',']','^[0-9]',"."};
	 //str.replace("[0]", "");
    System.out.println(str); 
	String newStr = "";
	String [] regex = {"[^[0-9]]","\\[","\\]","\\.\\."};
   //for(int i =0 ; i< regex.length ;i++){
	  newStr = str.replaceAll(regex[0],"").replaceAll(regex[1],"").replaceAll(regex[2], "").replaceAll(regex[3], ".");
 // }
   System.out.println(newStr);
 }
}
	

