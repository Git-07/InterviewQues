package Same_Array_Pattern;

public class ExtractOnlyNumericAndTotalCount {
	
	public static void main(String[] args) throws Exception{
		
		StringBuffer sfr = new StringBuffer("asdf213546wer");
		String sfr1 = "a%%&&**@@sdf2133333546wer";
		char [] sfr2 = sfr1.toCharArray();
		int counter = 0;
	    for(int i =0 ;i<sfr2.length ;i++){
		    	try {
		    	 if(Character.isDigit(sfr2[i])){		    		 
		    		 System.out.print(sfr2[i] + " ");
		    		 counter++;
		    	 }
		    	 }catch(NumberFormatException e){
		    		 
		    	 }
		    }
	    System.out.println();
	    System.out.println("Total digits in String are : " + counter);
		}


}
