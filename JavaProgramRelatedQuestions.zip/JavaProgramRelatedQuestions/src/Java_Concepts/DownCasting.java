package Java_Concepts;

class Class1{
	
	public void nonStaticNature(){
		System.out.println("From Class1");
	}
	
	public final void  finalFromClass1(){
		System.out.println("Final method from Class1");
		
	} 
}

class Class2 extends Class1{
	
	public void nonStaticNature(){
		System.out.println("From Class2");
	}
	
	public final void  finalFromClass2(){
		System.out.println("Final method from Class1");
		
	}	
}

public class DownCasting extends Class2 {

	static int i =0;
	public final void finalFromClass3(){
		
		System.out.println("Final method from Class3");
		System.out.println(i);	
	}	
	public static void main(String[] arg){
	
		//cl1.finalFromClass3();
		Class1 cl1 = new DownCasting();
		DownCasting dc = (DownCasting) cl1;
		dc.finalFromClass3();
		cl1.nonStaticNature();
	}

}
