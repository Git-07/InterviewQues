package Java_Concepts;

import java.util.ArrayList;

public class CreateNullPointerException {
	
	public static void main(String [] ar){
		
		String str = null; // null as an object
		String str2 =   "not null";
		ArrayList<String> arl = new ArrayList<String>();
		arl.add(null);
		try{
		if(str.equals(str2)){
			System.out.println("No null pointer exception");
		} 
		}catch(NullPointerException e){
			System.out.println("Null pointer exception in 1st compare");
		}	
		try {
		if(arl.get(0).equals(str2)){
			
			System.out.println("No null pointer exception");
		}
			}catch(NullPointerException e){
			System.out.println("Null pointer exception in 2nd compare");
		}
	}

}
