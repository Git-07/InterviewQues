package Java_Concepts;

class DataHider {
	
	private int i;
	private String s;
	
	public void setIntVal(int i) { // this is like depositing money button
		
		this.i = i;
		
	}
	public int getInatVal(){ // this is like money withdrawl button
		return this.i;
	}
    public void setStrinVal(String s) {
		
		this.s = s;
		
	}
	public String getStringVal(){
		return this.s;
	}
}

public class Encapsulation {

	public static void main(String [] ar){
		
		DataHider dh = new DataHider();
		dh.setStrinVal("Your bank account balance : ");
		dh.setIntVal(150);
		System.out.println(dh.getStringVal() + dh.getInatVal());
		
	}
	
}