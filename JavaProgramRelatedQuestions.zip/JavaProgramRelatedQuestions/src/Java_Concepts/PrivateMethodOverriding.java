package Java_Concepts;

class ParentWithPrivate{
	int a = 4;
	void nonPrivateMethod(){
		
		System.out.println("Non Private Method of Base Class");		
		
	}
	
	private void privateMethod(){
		System.out.println("Private Method of Parent class");
	}
	
	void getprivateMethod(){
		privateMethod();
	}
	
}

public class PrivateMethodOverriding extends ParentWithPrivate{
 
    //@Override
	private void privateMethod1(){
		System.out.println("Private Method of Child class");
	}
	public static void main(String [] ar){
	ParentWithPrivate pwp = new PrivateMethodOverriding();
	pwp.getprivateMethod();
	pwp.nonPrivateMethod();
    pwp.getprivateMethod();
	}
}
