package Java_Concepts;

public interface InterfaceJava7 {
	public static void staticInJava7(){
	
		System.out.print("");
	}
	

}
