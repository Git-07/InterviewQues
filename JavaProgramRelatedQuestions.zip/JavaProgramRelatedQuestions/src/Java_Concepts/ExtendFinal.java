package Java_Concepts;

final class FinalClass{
	
	int  i =0;
	String s;
	
	public  void finalClassMethod(){
		
		System.out.println("In final Class method");
		
	} 
	
	
}
public class ExtendFinal extends FinalClass{

}
