package Java_Concepts;

interface InAbstractClass{
	
	//public static void java7StaticMethod(){};
	//Error : 
	//Illegal modifier for the interface method java7StaticMethod; only public & abstract are permitted
	//Static methods are allowed in interfaces only at source level 1.8 or above
	
	public abstract void java7NonStaticMethod();
	public static  void java8StaticMethod(){
		
		System.out.println("Static method with concrete body");
	}
	public abstract static void methodM(){
		//Error : Illegal combination of modifiers for the interface method methodM; 
		//only one of abstract, default, or static permitted
	}
	
}
abstract class A {
	abstract void m1();
	abstract void m2();
	void m3(){
		System.out.println("I am not abstract");
			
	}
	
	default void methodInAbstract(){
		
	}
}

abstract class B extends A { // if not used abstract key word then it will throw a compile time error:
	 // Add unimplemented methods
	
	
	
}
public abstract class AbstractClass {
	
	public static void java7StaticMethod(){		
	
		AbstractClass abc = new AbstractClass();
		System.out.println("Static methods are allowed in abstract class but only concrete methods");
	}
	//Error :
	//The abstract method java7StaticMethod in type AbstractClass can only set a visibility modifier, 
	//one of public or protected
	
	abstract public void java7NonStaticMethod();

}
