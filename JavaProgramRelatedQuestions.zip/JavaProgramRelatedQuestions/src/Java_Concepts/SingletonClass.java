package Java_Concepts;

public class SingletonClass {
	
	private static SingletonClass sc = null;
	
	private SingletonClass(){
		
		System.out.println("Singleton class nvoked");
		
	}
	public static SingletonClass getSingletonClassIns(){
		
	try{	
	if(sc == null){
		System.out.println("Here to create the instance");
		sc = new SingletonClass();
	}
	}catch(NullPointerException e){
		System.out.println(e);
	}
	return sc;
}
}
