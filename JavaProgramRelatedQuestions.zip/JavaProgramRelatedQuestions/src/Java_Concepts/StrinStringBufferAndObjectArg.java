package Java_Concepts;

public class StrinStringBufferAndObjectArg {
	
	public  void  testMethod(String str){
		
		System.out.println("Invoked String Arg method");
	}
	public void testMethod(Object obj){
		
		System.out.println("Invoked Object Arg method");
	}
	
	public void testMethod(StringBuffer buffer){
		
		System.out.println("Invoked String buffer Arg method");
	}
	
	public static void main(String[] ar){
		
		StrinStringBufferAndObjectArg ssbao = new StrinStringBufferAndObjectArg();
		ssbao.testMethod(null);
		
	}
	

}
