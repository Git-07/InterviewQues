package Java_Concepts;


class OuterClass{
	
	static int x = 10;
	int y = 5;
	static private int z = 8;
	
	void outerClassMethod(){
		
		System.out.println("this is a non static method and cann not be accessed in static " +
		  "nested class without an object reference of outer class");
	}
	private class PrivateInnerClass{
		
		public static void main(String [] ar){
	//The method main cannot be declared static; static methods can only be declared in a static or top level type
			
		}
	}
	public class PublicInnerClass{
		
		public static void main(String [] ar){
	//The method main cannot be declared static; static methods can only be declared in a static or top level type	
			
		}
				
	}
	protected class ProtectedInnerClass{
		
		public static void main(String [] ar){
	//The method main cannot be declared static; static methods can only be declared in a static or top level type		
		}
	}
	default class DefaultInnerClass{
		
	}
	
	static class NestedClass{ //This is the static nested class but it has sm members which are non static so object needs to be created for this.
		//So far as its static members are concerned we can use them as ClassName.memberName
	
		
		OuterClass outerClassObj = new OuterClass();
	    public static void main(String [] ar){
	    	System.out.println(x);
			
		}
		void accessTheData(){
			
			System.out.println(x);
			//System.out.println(y);
			//Can not make static reference to a non static field
			System.out.println(outerClassObj.y);
			outerClassObj.outerClassMethod();
			System.out.println(z);
		}
		
	
		static int i = 9;
	
	}
	
}

public class StaticNestedClass {
	

	
	public static void main(String[] ar){
	
		OuterClass.NestedClass nestedClassObj = new OuterClass.NestedClass();
	    OuterClass outerClassObj = new OuterClass();
	    System.out.println(OuterClass.NestedClass.i);
	    nestedClassObj.accessTheData();
	    System.out.println(OuterClass.x);
	    System.out.println(outerClassObj.y);
	
	}	

}
