package Java_Concepts;

interface WithDefaultMethods{
	
	default void getTheVal(int i){
		
		System.out.println(i);
		
	}
	
	
}

public class OverrideDefaultMethod implements WithDefaultMethods{
	
	default void getTheVal(int i){
		
		System.out.println(i);
		
	}
	public static void main(String [] ar){
		
		WithDefaultMethods wd = new OverrideDefaultMethod();
		wd.getTheVal(1);
		
	}

}
