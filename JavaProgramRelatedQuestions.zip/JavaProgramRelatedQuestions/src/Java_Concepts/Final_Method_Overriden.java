package Java_Concepts;


class BaseClass {
	
	int j = 1;
	static boolean notDefined;
	final int uninitialised;
	static final String notInitialised;
	static{
		notInitialised = "Final Static Block is intialiser";
	}
	BaseClass(int i){
		this.uninitialised = i;
		notDefined = false;
	}
	BaseClass(){
		this(1);
	}

	final int i = 10;
	
	final void jan24Test(){		 
		System.out.println("In the final method jan24Test of Base Class");
		System.out.println(this.i);
	} 
}

public class Final_Method_Overriden extends BaseClass {
	
	  final int i = 20;
	  int j =5;
	  final   void jan24TestChild() {//Cannot override the final method from BaseClass		 
		 System.out.println("In the final method jan24TestChild of Child Class");
		 System.out.println(this.i);
		
	}
	
	  void jan24TestChild2(){
		  static int a = 9;
			 private int x = 8;
			 protected int y = 7;
			 public int z = 9;
			 default int i = 9;
			 final int w = 9;
			 99
			 super.jan24Test();
	  }
	 
	 public static void main(String [] ar){
		 
		 BaseClass b = new Final_Method_Overriden();
		 //Final_Method_Overriden fm = (Final_Method_Overriden) b; //downcasted
		 Final_Method_Overriden fm = new Final_Method_Overriden();
		 b.jan24Test();
		 System.out.println(b.j);
		 System.out.println(fm.j);
		 System.out.println(b.uninitialised);
		 System.out.println(fm.i);
		 //fm.jan24TestChild();
		
		 fm.jan24Test();
		 
	 }
	
	
}
