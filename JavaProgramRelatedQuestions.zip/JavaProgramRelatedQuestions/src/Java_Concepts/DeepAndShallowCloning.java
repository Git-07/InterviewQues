package Java_Concepts;


class ShallowCloning{
	
	int x ;
	int y ;
	ShallowCloning(int x, int y){
		this.x = x;
		this.y = y;
	}
   
	public int getIntVal(){
		
		return x;
	} 
	
}
class DeepCloning implements Cloneable{
	
	int x ;
	int y ;
	DeepCloning(int x, int y){
		this.x = x;
		this.y = y;
	}
   
	public int getIntVal(){
		
		return x;
	} 
	// deep cloning by overriding clone method in the class
	   protected Object clone() throws CloneNotSupportedException
	    {
	    	
	    	return (DeepCloning)super.clone();

	    }
}

public class DeepAndShallowCloning {
	
	public static void main (String [] ar){
		
		DeepCloning dc =  new DeepCloning(1,2);
		try {
			
			//explicitly called overrided clone method in the class	
			DeepCloning dc2 = (DeepCloning) dc.clone(); 
			
			//DeepCloning dc2 = dc; //this will give the Shallow Cloning
			dc2.x = 4;
			System.out.println(dc.getIntVal());
			System.out.println(dc2.getIntVal());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ShallowCloning sc=  new ShallowCloning(1,2);
		
		ShallowCloning sc2 = (ShallowCloning) sc; // Type casted the reference,So both references are pointing to same object 
		sc2.x = 5; // the change done by the reference impacted the first object r
		System.out.println(sc.getIntVal());
		System.out.println(sc2.getIntVal());
	}

}
