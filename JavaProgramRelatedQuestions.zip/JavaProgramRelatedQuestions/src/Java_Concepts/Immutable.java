package Java_Concepts;

import java.util.HashMap;
import java.util.Map;

//Cloning related is already discussed in Deep cloning
public final class Immutable implements Cloneable{
	
	private final int i;
	private final String s;
	private final boolean bool;
	private final char ch;
	Immutable(int i, String s, boolean bool, char ch){	
	this.i = i;
	this.s = s;
	this.ch = ch;
	this.bool = bool;		
	}

	private final HashMap<String,String> map = new HashMap<String,String>();
	
	public HashMap<String,String> getTheStringValue(){
		
		HashMap<String, String> maps = (map);
	
		return maps;
	}
	
   protected Object clone() throws CloneNotSupportedException
    {
    	
    	return (Immutable)super.clone();
    }
	
}
