package Java_Concepts;

class Base{
	
	static String a = "Parent Class";
	static int b ;
	static void baseClassMethod(){
		
		System.out.println("Base Class static method if polymorphism is not success");
		this.b = 10; //Cannot use this in a static context
	}

	
	void nonStaticMethod(){
		
		System.out.println("Base Class Non static method");
	}
	
	int nonStaticMethod(int a){
		
		System.out.println("Base Class method overloaded in Parent class");
		this.b = a;
		return 0;
	}

	
	static void baseClassMethodpolymorphism(){
		
		System.out.println("Base Class static method if polymorphism is not success");
	}
	
	static void baseClassMethodpolymorphism(int a){
		
		System.out.println("Base "
				+ "Class static method if polymorphism is not success 'baseClassMethodpolymorphism' is overloaded");
	}
	
	
}
public class Static_Method_Polymorphism extends Base{

	 static String a = "Child Class";
	 //Base class non static method can be overloaded n child class
	
	 Static_Method_Polymorphism(){
		 
	 } 
		int nonStaticMethod(int a , int b){
			
			System.out.println("Base Class non static method Overloaded in child class");
			return 0;
		}
		
	    String nonStaticMethod(int a , String s){
	 		
	         System.out.println("Child Class non static method - Let see if JVM picks me - Polymorphism successfull");
	   		
	         return "";
	   	}
	        
		
		 //Base class static method can be overloaded in child class
		static void baseClassMethodpolymorphism(int a , int b){
			
			System.out.println("Base Class static method overloaded in child class");
		}
		 //But Base class  static method can't  be override in child class
		//This concept is called method hiding
	static void baseClassMethod (){	// This is copy of base class method but as per our use we will use this.
		System.out.println("Child class method if polymorphism is successfull");		
     }
	 
     int nonStaticMethod(int a){
		
      System.out.println("Child Class non static method - Let see if JVM picks me - Polymorphism successfull");
		
      return 0;
	}
     
     int nonStaticMethod(int a,int b , int c){
 		
         System.out.println("Child Class non static method - Let see if JVM picks me - Polymorphism successfull");
   		
         return 0;
         //return "";
   	}
        
     
     void nonStaticMethod(){
 		
 		System.out.println("Child Class Derived Non static method if polymorphism is successfull");
 	}
	static void baseClassMethodpolymorphism(int a){
		
		System.out.println("Child Class Derived static method if polymorphism is success");
	}


	void freshChildClassMethod(){
		
		System.out.println("Fresh method in child class");
	}
	
	
	public static void main(String[] ar){
		Base b = new Static_Method_Polymorphism();
		Static_Method_Polymorphism smp = new Static_Method_Polymorphism();
		baseClassMethod();
		b.baseClassMethod();
		b.nonStaticMethod();
		b.nonStaticMethod(1);
		b.nonStaticMethod(1,2);
		smp.freshChildClassMethod();
		System.out.println("From Base: " + b.a);
		System.out.println("From Child: " + smp.a);
	
	}	
}
