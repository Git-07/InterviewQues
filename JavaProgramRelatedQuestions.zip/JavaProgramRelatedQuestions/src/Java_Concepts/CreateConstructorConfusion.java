package Java_Concepts;

public class CreateConstructorConfusion {

	CreateConstructorConfusion(int a, float b){
		System.out.println("From 1st a : " + a + " b : " + b);
	}
	
	CreateConstructorConfusion(float a, int b){
		System.out.println("From 2nd a : " + a + " b : " + b);
	}
	
	CreateConstructorConfusion(float a, float b){
		System.out.println("From 3rd a : " + a + " b : " + b);
	}
	
	public static void main(String [] ar){
		int a = 10;
		int b = 20;
		//ERROR ->  The constructor CreateConstructorConfusion(int, float) is ambiguous
		CreateConstructorConfusion cc = new CreateConstructorConfusion(a,b); 
		
	}
}
