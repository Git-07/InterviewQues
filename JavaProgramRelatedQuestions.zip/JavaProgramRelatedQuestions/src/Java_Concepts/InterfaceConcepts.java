package Java_Concepts;

 interface InterfaceConcepts {

	int i ; //Error: The blank final field i may not have been initialized
	public static void staticInJava7(){
		
	}

}
 
 interface InterfaceConcepts2{
	 
	 int a;
	 String str;
	 public static void staticInJava7(){
			
		}
	 
 }

abstract class AbsrtactConcepts implements InterfaceConcepts,InterfaceConcepts2{
	
	 int j;
	 AbsrtactConcepts(int j){
		 this.j = j;
		 System.out.println(this.j);
	 }
		public static void abstaticInJava7(){
			
		}
	 
	// InterfaceConcepts intf = new AbsrtactConcepts();//Error : Cannot instantiate the type AbsrtactConcepts
	 	 
}

 class Extender extends AbsrtactConcepts{
	
	Extender(int j){
		super(j);
	}
	public static void main(String [] ar){
	AbsrtactConcepts abc = new Extender(10);
	InterfaceConcepts.i = 0; //Error : The final field InterfaceConcepts.i cannot be assigned
	System.out.println(i);
	}
	
}
