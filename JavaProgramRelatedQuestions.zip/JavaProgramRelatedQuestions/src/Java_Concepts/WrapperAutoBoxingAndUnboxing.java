package Java_Concepts;

public class WrapperAutoBoxingAndUnboxing {

	public static void main(String [] ar){
	
		Integer i = new Integer(5);
		int x = i; // auto unboxing done by compiler
		int y = i.intValue(); // explicit unboxing done manually
		System.out.println(y);
		Integer j = y  ;// auto boxing done by compiler
		Integer z = Integer.valueOf(y); // explicit boxing done manually
	
	
}
	
	public static void main(int [] a){
		
	}
	
}
