package Java_Concepts;

class Parent{
	
	public void getData(){
		
		private int a = 2;
		System.out.println("123");
		
	}
}

public class ParentClassError extends Parent{
	
	void getVal(){
		//super.getData();
		System.out.println("35363");
	}
	public static void main(String [] ar){
		
		ParentClassError pce = new ParentClassError();
		
		pce.getVal();
	}

}
