package Java_Concepts;

/* Note : 
 
 To instantiate an inner class, you must first instantiate the outer class.
  Then, create the inner object within the outer object with this syntax:
  OuterClass outerObject = new OuterClass();
 OuterClass.InnerClass innerObject = outerObject.new InnerClass();
 */


class OuterClassTest{
	static int x = 2;
	int y = 4;
	private int z = 6;
	
	
class InnerClass{
		
		void accessTheData(){
			
			System.out.println(x);//no error in accessing static variable or member	of the outer class		
			System.out.println(y);
			System.out.println(z);
		}
		static void testForStaticMethod(){ 
			
//The method testForStaticMethod cannot be declared static; static methods can only be declared in a static or top level type			
		}
	
	}
	static class insideInnerClass{
		
		public void testNonStaticInStaticInnerClass(){
			
		System.out.println(y);///Cannot make a static reference to the non-static field y
		}
		
		interface innerInterface{ //un implemented interface 
			
			void inTheInnerInterface();			
			
		}
	}
	interface InnerInterface{ //un implemented interface 
		
		void inTheInnerInterface();
		
	}
	
}


public class InnerClassesConcept {
	
	public static void main(String [] ar){
	OuterClassTest outerClassObj = new OuterClassTest();
	OuterClassTest.InnerClass innerClassObj = outerClassObj.new InnerClass();
	innerClassObj.accessTheData();
	}

}
