package Java_Concepts;

public class SingletonCaller {
	
	public static void main(String [] ar){
		
		SingletonClass firstcall = SingletonClass.getSingletonClassIns();
		SingletonClass secondcall = SingletonClass.getSingletonClassIns();
		SingletonClass thirdcall = SingletonClass.getSingletonClassIns();
		System.out.println(firstcall);
		System.out.println(secondcall);
		firstcall.getSingletonClassIns();
		secondcall.getSingletonClassIns();
		System.out.println(firstcall.equals(secondcall));
		
	}

}
