package Java_Concepts;

public class MyOwnExceptionClass extends Exception {
	
	 public MyOwnExceptionClass(){
		
		super();		
	}	
	 
	 public MyOwnExceptionClass(String str){
			
			super(str);		
		}	
	
	public static void main(String[] ar){
		
		try{
		throw new MyOwnExceptionClass("Exception caught"); //Throw an object of user defined exception				
			
		}catch(MyOwnExceptionClass e){
			//System.out.println("Exception caught");
			System.out.println(e);
		}
		String str1 = "asdf";
		String str2 = "asd";
		
		if(!str1.equals(str2)){
			
			try {
				throw new Exception("Strings are not equal");
			} catch (Exception e) {
				//System.out.println(e);
				e.printStackTrace();
			}
		}
		int a = 10;	
		// Below is the representation of how to use throw keyword
		for(int i = 0 ; i< 3 ; i++){
			
			if (i == 0){
				
				throw new ArithmeticException("Please remove division by zero");
			}
			
			int b = a/i;				
			if(b < 6){
							
				throw new SecurityException("Please stop division as the number a is already decreased to half");			
			}
			
			
		}
	}

}
