package Java_Concepts;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.Serializable;

public class SerializationAndDeserializationClass implements Serializable{
	
	int a =2;
	String s = "Mohit";
	
	public static void main(String[] ar){
	SerializationAndDeserializationClass sc = new SerializationAndDeserializationClass();
	OutputStream os = null;
	try {
		os = new FileOutputStream("");
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	try {
		ObjectOutputStream oos = new ObjectOutputStream(os);
		
		//Serialization happened here
		oos.writeObject(sc);
	}catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
	//Below where deserialization process
		
	InputStream is = null;
	try {
	is = new FileInputStream("");
	ObjectInputStream ois = new ObjectInputStream(is);
	
	SerializationAndDeserializationClass sc1 = new SerializationAndDeserializationClass();
	
	
		//Deserialization happened here
		sc1 = (SerializationAndDeserializationClass)ois.readObject();
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		
  catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
	
	}
}
