package Java_Concepts;

import java.io.IOException;

public class Garbage_Collector {
	
    int j=12;  
    void add()  
    {  
        j=j+12;  
        System.out.println("J="+j);  
    }  
    public void finalize() throws Throwable 
    {  
         
        int i = 0;
        int b =1;
        try{
        int c = b/i;
        }catch(Exception e){}
        System.out.println(this + " Object will be garbage collected");
    }  
    public static void main(String[] args) throws IOException {  
/*       new Garbage_Collector().add();  
        new Garbage_Collector().add();
        System.gc();
        System.runFinalization();
        Garbage_Collector g1 = new Garbage_Collector();
       // System.out.println(g1);
        g1.add();
        g1 = null;
        System.gc();
        System.runFinalization();
        Garbage_Collector g2 = new Garbage_Collector();
        //System.out.println(g2);
        g2.add();
        g2 = null;
        System.gc();
        System.runFinalization();*/
    	Garbage_Collector g1 = new Garbage_Collector(); 
    	Garbage_Collector g2 = new Garbage_Collector();
    	g1  = g2;// here g1 Object is collected by GC

    	//Here the object is collected by garbage collector as the 1st object referred by g1 has no reference to it.  
        System.gc();
    	        
       	//finalize method called here if overriden then those task will be completed first before garbage collection
    	// if user wont give explicitly this will be automatically called at the end of the program and it will 
    	System.runFinalization();                         
        String a = "in Heap";
        String b = "Test";
        a = b;
        //[Imp : ] Here the String literal object is not collected by garbage collector as "in Heap" has no reference to it.
        //System.gc();
        //System.runFinalization(); 
             
        System.out.println("the value of b : " + b);
        System.out.println("the value of a : " + a);
        //System.gc();
        
        try {
			//g1.finalize();
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		}//here g2 Object is collected by GC
        
    }
}
