package Java_Concepts;

interface Interf{ //un implemented interface 
	
	void inTheInterface();
	void anotherMethod(int a);
	
}
class OuterClassTestCont{
	static int x = 2;
	int y = 4;
	private int z = 6;
	
	
	class InnerClass{ // non static inner class
		
		void accessTheData(){
			
			System.out.println(x);//no error in accessing static variable or member			
			System.out.println(y);
			System.out.println(z);
		}
	
	}	

}



public class AnonymousInnerClass {
	
	public static void main(String [] ar){
	OuterClassTestCont outerClassObj = new OuterClassTestCont();
	OuterClassTestCont.InnerClass innerClassObj = outerClassObj.new InnerClass();
	innerClassObj.accessTheData();
	Interf interf = new Interf()//It means u are implementing it even without using keyword 'implements'.So have to write the method body
	{
		public void inTheInterface(){
			
			System.out.println("Implemented an anonymous inner class here");
		}
	};
	interf.inTheInterface();
	}

}
