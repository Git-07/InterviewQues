package Java_Concepts;

public class StopObjectCreation {
	
	StopObjectCreation obj;
	final int a;
	static int counter;
	static final int s;
	static {
		s = 12;
	}
	StopObjectCreation(){
		++counter;
		a = 1;
	}
	
	public  StopObjectCreation getObject(){
		
		if(counter < 5){
		obj = new StopObjectCreation();		
		System.out.println(obj);
		}
		else {
			System.out.println("It can have maximum of 4 instances");
			//obj = null;
		}
		
		return obj;
	}
	
	public static void main(String [] ar){
		
		StopObjectCreation obj = new StopObjectCreation();
		StopObjectCreation obj1 = new StopObjectCreation();
		StopObjectCreation obj2 = new StopObjectCreation();
		StopObjectCreation obj3 = new StopObjectCreation();
		StopObjectCreation obj4 = new StopObjectCreation();
		StopObjectCreation obj5 = new StopObjectCreation();
		StopObjectCreation obj6 = new StopObjectCreation();
		//obj4.getObject();
		try{
			System.out.println(obj.getObject());
			System.out.println(obj1);			
			System.out.println(obj5.getObject());
			//System.out.println(obj6.getObject());
		
		//System.out.println(obj5.getObject().equals(obj6.getObject()));
		}catch(NullPointerException e){}

		
	}

}
