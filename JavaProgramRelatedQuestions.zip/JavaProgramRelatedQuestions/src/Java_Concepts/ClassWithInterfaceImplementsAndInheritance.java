package Java_Concepts;

 interface TestInterf {
	
	public static void staticM(){		
		System.out.println("staticMethod in interface : TestInterf");
	}
	
}

class InterfaceImplementer implements TestInterf{
	
	public static void staticM(){
		
		System.out.println("staticMethod in class : InterfaceImplementer");
	}
	
	public void nonstaticM(){
		
		
	}
}

public class ClassWithInterfaceImplementsAndInheritance extends InterfaceImplementer {
	
	public static void staticM(){
		
		System.out.println("staticMethod in class : ClassWithInterfaceImplementsAndInheritance");
	}
	
	

	
	public static void main(String[] ar){
	
		InterfaceImplementer interf = new ClassWithInterfaceImplementsAndInheritance();
		interf.staticM();
		InterfaceImplementer.staticM();
		TestInterf.staticM(); //here interface name dot static method name working
		String s1 = "Apple";
		String s2 = s1;
	
	}

}
