package Java_Concepts;


public class Enumeration {
	//To define our own data type -> main purpose
	//a group of named constant -> concept of enum
	enum Teams{
		
		TestNewYorSOPTeam("TestNew"),
		MemberName("Jian"),
		ABCTeam("ABC"),		
		ABCMember("ABCMEm");
		String nameAndMember;
		Teams(String teamAndMember){
			this.nameAndMember = teamAndMember;
		}
		
		public void enumCanHaveMethod(){ // enum can have methods
			
		}
		Teams(){ // enum can have constructor
			
		}
	}
	
	 enum Month {
		//By default every enum constant is always public static final 
		//Every Enum constanr represent the type of that enum object
		Jan("Peak Winter"),Feb("Winter"),March,April,May,Jun,July;
		Month(String str){
			
			System.out.println("this will be called on call to each constant with Parameter");         	
			
		}
		Month(){
			
			System.out.println("this will be called on call to each constant without Parameter");
		}
	 }
	public static void main(String[] ar){
		
		String team ="";
		String member ="";
		Teams t1 = new Teams();
		for(Teams t : Teams.values()){
			
			switch(t){
			case TestNewYorSOPTeam : 
				team = t.nameAndMember;
			break;
			case MemberName :
				member = t.nameAndMember;
			}
		}
		
		System.out.println(Month.Jan);
		//System.out.println(CesData.plaintiff);
		//CesData ces = CesData.plaintiff;
		
		
	}

}
