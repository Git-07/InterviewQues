package Java_Concepts;


public class DeadLock {
	
	public static void main(String [] ar){
	String resource1 = "ABCD";
	String resource2 = "XYZ";
	
	Thread t1 = new Thread(){ // Anonymous inner class
		
		public void run(){
		
			synchronized(resource1){
				System.out.println("Thread 1 locked resurce 1");
				try {
					Thread.sleep(6000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} 
	/*		try {
				Thread.sleep(16000);
			} catch (InterruptedException e) {
				
			}*/
			
			synchronized(resource2){
				System.out.println("Thread 1 locked resurce 2");
			}
		}
	};
	
	Thread t2 = new Thread(){
		
		public void run(){
		
			synchronized(resource2){
				System.out.println("Thread 2 locked resurce 2");
			} 
			try {
				Thread.sleep(16000);
			} catch (InterruptedException e) {
				
			}
			
			synchronized(resource1){
				System.out.println("Thread 2 locked resurce 1");
				}
		}
	};

	t1.start();
	t2.start();
}
}
