package Java_Concepts;

public class HelloWorlWithoutSemiColon {

	
	public static void main(String[] ar){
		
		String str1 = "asdf";
		String str2 = "asd";
		
			
		if(System.out.printf("Hello world" + "\n") == null || 1 == 1){
			//System.out.println("Hello World With semicolon");
		}
		if(System.out.append("Hello World") == null){
			//System.out.println("Without semicolon");
			
		}
		String str = "Name : Mohit Latwal%nAddress: HN 123 Lodhiya Almora%nCurrent Location : Bangalore";
		System.out.printf("Name : Mohit Latwal%nAddress: HN 123 Lodhiya Almora%nCurrent Location : Bangalore");
		System.out.printf(str);
	}
}
