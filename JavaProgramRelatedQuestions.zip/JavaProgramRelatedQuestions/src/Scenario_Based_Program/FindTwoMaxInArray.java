package Scenario_Based_Program;

public class FindTwoMaxInArray {
	
	
	public static void getTwoMax(int [] it){
		int firstMax =0;
		int secondMax = 0;
		for(int i=0; i<it.length ; i++){
			//int temp = it[i];
			if(firstMax < it[i]){
				secondMax = firstMax;
				firstMax = it[i];				
			}
			else if(secondMax < it[i]){
				secondMax = it[i];
			}
			
		}
		System.out.println(firstMax);
		System.out.println(secondMax);

	}
	
	public static void  main(String [] ar){
		
		int [] ia = {12,77,67,80,79,99};
		getTwoMax(ia);
		
	}

}
