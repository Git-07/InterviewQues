package Scenario_Based_Program;

public class FindTwoMinInArray {
	
	public static void getTwoMin(int [] it){
		
		int firstMin = it[0];
		int secondMin = it[0];
		for(int i=0; i<it.length ; i++){
			
			if(firstMin > it[i]){
				secondMin = firstMin;
				firstMin = it[i];
			}
			else if(secondMin > it[i]){
				secondMin = it[i];
			}

		}
		System.out.println(firstMin);
		System.out.println(secondMin);
	}

	public static void main(String [] ar){
		
		int [] ia = {121,13,77,56,484,11};
		getTwoMin(ia);
	}
}
