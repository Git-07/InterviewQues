package Scenario_Based_Program;

public class AddressBookValidatePhoneNum {

	//Write a query for list all employees who name having more than 4 characters
	static String [] names = {"Mack", "Jack","Apple","Bangalore","Mysore"};
	
	
	//Write a query to find if the phone number is already present in the address book;
	
	static String [] phone = {"9082390821","782137821","072132813","27187328"};
	static String [] email = {"abc@gmail.com","adc@gmail.com","awq@gmail.com","qwer@gmail.com"};
	static String [] name = {"Mack","Jack Leach","John S","Payal P"};
	
	public static void main(String []  ar){
		
		//Write a query for list all employees who name having more than 4 characters
		getEmployeesNames(names);
		
		System.out.println();
		
		//Write a query to find if the phone number is already present in the address book;
		System.out.println(validatePhone("90823908"));	
	}
	
	public static void getEmployeesNames(String [] names){
		
		String[] str = names;
		for(int i =0 ;i< str.length ; i++){
		if(str[i].length() >= 4){
			
			System.out.print(str[i] + " ");
		}
		
	}
	}
	

	public static String validatePhone(String ph){
		
		String message = "";
		for(int i=0; i<phone.length; i++){
			
			if(phone[i].equals(ph)){
				message = "Phone number is already exist";
				break;
			}
			else {
				message = "Phone number is not present";
			}
			
		}	
		return message;
	}

}
