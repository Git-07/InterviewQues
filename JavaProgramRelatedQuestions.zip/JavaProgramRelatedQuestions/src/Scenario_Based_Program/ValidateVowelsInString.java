package Scenario_Based_Program;

public class ValidateVowelsInString {

	public static void validateVowels(String str){
		
		String message = "";
		//String vowels = ".*[aeiou].*";
		String vowels = ".*[aeiou]*";
		if(str.matches(vowels)){
		message = "Vowels are present";
	   }
		else {
			message = "No vowels are present";
		}
		System.out.println(message);
	}
	
	public static void main(String [] ar){
		
		validateVowels("Mohit");

		
	}
	
}
