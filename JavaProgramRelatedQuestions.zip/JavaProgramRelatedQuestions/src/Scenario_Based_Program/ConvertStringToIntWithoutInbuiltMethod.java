package Scenario_Based_Program;

public class ConvertStringToIntWithoutInbuiltMethod {
	

	public static void converStringToInt(String str){
		int num =0;
		for(int i =0 ;i<str.length() ;i++){
		
			num = num*10 + ((int)str.charAt(i) - (int)('0'));
			
		}
		System.out.println(num);
	}
	
	public static void main(String [] ar){
		
		converStringToInt("12334");
	}

}
