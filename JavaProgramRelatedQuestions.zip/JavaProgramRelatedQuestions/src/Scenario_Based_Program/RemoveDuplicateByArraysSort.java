package Scenario_Based_Program;

import java.util.Arrays;

public class RemoveDuplicateByArraysSort {
	
	public static void main(String [] ar){
		
		String str = "aaaassssdfASDFasdffggfa";
		//StringBuilder sbr = new StringBuilder(str);
		char [] ch = str.toCharArray();
		Arrays.sort(ch);
		System.out.println(ch);
		char co =' ';
	    for(int i=0 ;i <ch.length ; i++){
		  char ci = ch[i];
		  if(ci != co){
			  System.out.print(ci + "");
			  co = ci;
		  }
		 	  
	   }
	}

}
