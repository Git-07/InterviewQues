package Scenario_Based_Program;

public class PlusOPeratorPrecedenceOverEquals {
	
	public static void main(String [] ar){
		
		String str1 = "Mohit";
		String str2 = "Mohit";
		System.out.println(str1 == str2);
		System.out.println("str1 == str2 is:" + str1 == str2);
	}
	
	/*Explanation: The Second statements output will be �false� 
because in java + operator precedence is more than == operator.
So the given expression will be evaluated to �str1 == str2 is:Mohit� == �Mohit� i.e false.*/



}
