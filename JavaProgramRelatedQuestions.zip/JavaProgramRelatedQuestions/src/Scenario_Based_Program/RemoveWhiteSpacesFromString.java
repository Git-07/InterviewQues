package Scenario_Based_Program;

//**Imp .split will not work or not to use
public class RemoveWhiteSpacesFromString {
	
	public static void removeWhiteSpace(String str){
		
		char [] ch = str.toCharArray();	
		StringBuilder build = new StringBuilder();
		
		for(Character c : ch){
			if(c != ' '){
			build.append(c);
		}
		}
		System.out.println(build);
		
	}
	

	public static void main(String [] ar){
		
		removeWhiteSpace("M oh i t     La t wa l");
		
	}
	
	/*String [] st1 = str1.split("\\s+");
	String [] st2 = str2.split("\\s+");*/

}
