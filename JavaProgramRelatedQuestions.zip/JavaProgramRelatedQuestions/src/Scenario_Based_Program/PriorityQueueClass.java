package Scenario_Based_Program;
import java.util.*;
class Employee{
	int salary;
	String name;
	String designation;
	public Employee(String name, int salary , String designation){
		this.name = name;
		this.salary = salary;
		this.designation = designation; 
	}		
	public String toString(){
		return name + " : " + salary + " : " + designation;
	}
}
class SortBySal implements Comparator<Employee>{ // Comparator is interface

	@Override
	public int compare(Employee e1, Employee e2) {
	
		return e1.salary - e2.salary;
	}	
}
class SortByName implements Comparator<Employee>{
	
	public int compare(Employee e1, Employee e2){
		
		return e1.name.compareTo(e2.name);
	}
}
class SortByDesignation implements Comparator<Employee>{
	
	@Override
	public int compare(Employee e1, Employee e2){
		return e1.designation.compareTo(e2.designation);
	}
	
}
public class PriorityQueueClass {
 
	public static void main(String[] a){
		SortBySal comparator1 = new SortBySal();
		SortByName comparator2 = new SortByName();
		SortByDesignation comparator3 = new SortByDesignation();
		PriorityQueue<Employee> pQueue = new PriorityQueue<Employee>(6, comparator3);
		
		pQueue.offer(new Employee("Tom",213546 , "Fitter"));
		pQueue.offer(new Employee("Jhon",23546, "Cutter"));
		pQueue.offer(new Employee("Sejal",22113546, "Cleaner"));
		pQueue.offer(new Employee("Harry",2546, "Doctor"));
		pQueue.offer(new Employee("Tim",21354, "Singer"));
		pQueue.offer(new Employee("Tom",213, "Actor"));
		Iterator<Employee> itr = pQueue.iterator();
		while(itr.hasNext()){
		System.out.println(pQueue.poll());
	} 
	
	}
}
