package Scenario_Based_Program;

import java.util.Arrays;

public class AnagarmOfStringsUsingindexOfMethod {
	
	
	public static void main(String [] str){
	
    //For two Strings
	String str1 = "AsdfAA";
	String str2 = "fdsAA   A";
	String st = str2.replaceAll("\\s", "");
	char[] ch = st.toCharArray();
	if(str1.length() != st.length()){
		System.out.println("Strings are not anagram");
	}

	else /*if(str1.length() == str2.length())*/{
	int flag = 0;
	for(int i=0 ; i<ch.length ; i++){
		
	int index = str1.indexOf(ch[i]);
		if(index == -1){		
		flag = 1;
		System.out.println("Strings are not anagram");
		break;
	 }	
	}
	if(flag == 0){
	System.out.println("Strings are anagram");
	}
	}
	//for Two String Arrays
	String [] str3 = {"Abcd","Efgh","Ijkl mn"};
	String []  str4 = {"Efgh","Abcd","Ijklmn"};	
	String str5 = Arrays.toString(str3).replace("[","").replace(",", "").replace("]", "").replaceAll("\\s+", "");
	String str6 = Arrays.toString(str4).replace("[", "").replace(",", "").replace("]", "").replaceAll("\\s+", "");
	char [] ch2 = str6.toCharArray();
	if(str5.length() != str6.length()){
		
		System.out.println("Strings Arrays are not Anagaram");
	}
	else{
		int flag =0;		
		for(int j=0 ; j<str5.length() ; j++){			
			int index = str5.indexOf(ch2[j]);			
			if(index == -1){				
				flag = 1;
				System.out.println("String Arrays are not Anagaram");
				break;
			}			
		}
		if(flag == 0){
			System.out.println("String Arrays are Anagram");
		}
		
	}
	}
	
}
