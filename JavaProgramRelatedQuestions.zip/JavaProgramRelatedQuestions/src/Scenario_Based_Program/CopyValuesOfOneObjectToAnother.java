package Scenario_Based_Program;

public class CopyValuesOfOneObjectToAnother {
	
	String name ="";
    int id;
    
    String nameCopied ="";
    int idCopied ;
    CopyValuesOfOneObjectToAnother(String name, int id){
    	
    	this.name= name;
    	this.id = id;
    	
    }
    
    CopyValuesOfOneObjectToAnother(CopyValuesOfOneObjectToAnother c1){
    	
    	nameCopied =  c1.name;
    	idCopied = c1.id;
    	
    }
    
    void display(CopyValuesOfOneObjectToAnother c1,CopyValuesOfOneObjectToAnother c2){
    	
    	System.out.println("Copied name is :" + c2.nameCopied +" and copied id is : " + c2.idCopied);
    	System.out.println("name is :" + c1.name +" and id is : " + c1.id);
    }
    
   void displayWithoutPassingObjectReference(){ // So only the called Object will get the values of the variables
    	
    	System.out.println("name is :" + nameCopied +" and id is : " + idCopied);
    	System.out.println("name is :" + name +" and id is : " + id);
    }

    public static void main(String [] ar){
    	
    	CopyValuesOfOneObjectToAnother c1 = new CopyValuesOfOneObjectToAnother("Mohit",1052416);
    	CopyValuesOfOneObjectToAnother c2 = new CopyValuesOfOneObjectToAnother(c1);
    	c2.display(c1,c2);
    	
    }
}
