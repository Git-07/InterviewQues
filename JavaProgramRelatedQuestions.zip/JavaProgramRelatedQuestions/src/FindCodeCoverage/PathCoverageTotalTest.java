

package FindCodeCoverage;

//Path Coverage ensures coverage of all the paths from start to end.

public class PathCoverageTotalTest {
	
	public static void totalTestRequired(int x , int y){
		
		if(x+y > 20){
			
			System.out.println("Top");
			
	    }
		else {
			System.out.println("else statement");
		}
		if(x>50){
			
			System.out.println("Down");
		}
		else {
			System.out.println("2nd else statement");
		}
	}
	
	public static void main(String [] ar){
		
		totalTestRequired(2,2);
		totalTestRequired(22,2);
		totalTestRequired(51,2);
		totalTestRequired(55,-50);
		
	}

}
