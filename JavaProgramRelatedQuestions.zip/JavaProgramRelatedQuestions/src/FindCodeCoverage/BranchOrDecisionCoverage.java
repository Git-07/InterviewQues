package FindCodeCoverage;

/** URL : https://www.simform.com/blog/test-coverage/ **/

//Branch coverage can be calculated by finding the minimum number of paths which ensure that all the edges have been covered

public class BranchOrDecisionCoverage {
	
	public static void totalTestRequired(int x , int y){
		
		if(x+y > 20){
			
			System.out.println("Top");
			
	    }
		else {
			System.out.println("1st else statement");
		}
		if(x>50){
			
			System.out.println("Down");
		}
		else {
			System.out.println("2nd else statement");
		}
	}
	
	public static void main(String [] ar){

		totalTestRequired(20,2);
		totalTestRequired(55,-50);
		
		
	}


}
