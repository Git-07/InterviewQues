package FindCodeCoverage;

// Statement coverage ensures that all the statements in the source code have been tested at least once
//Note: It covers only true conditions of every statement.

public class StatementCoverage {
	
	public static void totalTestRequired(int x , int y){
		
		if(x+y > 20){
			
			System.out.println("Top");
			
	    }
		else {
			System.out.println("1st else statement");
		}
		if(x>50){
			
			System.out.println("Down");
		}
		else {
			System.out.println("2nd else statement");
		}
	}
	
	public static void main(String [] ar){

		totalTestRequired(55,50);
		
		
	}

}
