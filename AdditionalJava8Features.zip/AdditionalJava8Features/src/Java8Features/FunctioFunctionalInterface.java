package Java8Features;

import java.util.function.Function;

class FunctionOperation{
	
	Function<Integer,Integer> square = i -> i*i;
	Function<Integer,Integer> cube = i -> i*i*i;
    Function<String,Integer> length = l -> l.length();
    Function<String,String> upper = s -> s.toUpperCase();
    Function<String,char []> charArray = s -> s.toCharArray();
    Function<Integer,String> armStrong = i ->{
        int reverse = 0;
        String message = "";
    	int temp = i;
    	while(temp > 0){
    		int rem = temp%10;
    		reverse = reverse*10 + rem;
    		temp = temp/10;
    	}
    	message = (reverse == i)? "Number is armstrong":"Number is not Armstrong";
    	return message;
    };
}


public class FunctioFunctionalInterface {
	
	public static void main(String [] ar){
	FunctionOperation fm = new FunctionOperation();
	System.out.println(fm.square.apply(6));
	System.out.println(fm.cube.apply(6));
	System.out.println(fm.length.apply("Mohit"));
	System.out.println(fm.upper.apply("Mohit"));
	System.out.println(fm.armStrong.apply(1111));
	System.out.println("============================");
	System.out.println(fm.square.andThen(fm.cube).apply(3));
	System.out.println("============================");
	System.out.println(fm.square.compose(fm.cube).apply(3));
	}
}
