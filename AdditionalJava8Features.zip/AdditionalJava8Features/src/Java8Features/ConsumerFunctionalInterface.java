package Java8Features;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

class ConsumerOperation{
	
	Consumer<Integer> cons = i -> System.out.println(i);
	Consumer<List<String>> student = list -> 
	//forEach Traversing
	list.stream().forEach(
			str -> System.out.println(str)
		
	);
	//using advanced for loops
/*	{
		for(String str : list){
			
			System.out.println(str);
		
	}
		};*/
}


public class ConsumerFunctionalInterface {

	public static void main(String[] str){
		
		ConsumerOperation co = new ConsumerOperation();
		co.cons.accept(4);
		List<String>  lst = new ArrayList<String>();
		lst.add("Mack");
		lst.add("Jack");
		lst.add("John");
		co.student.accept(lst);
 	}
	
}
