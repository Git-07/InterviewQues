package Java8Features;

public abstract class AbstractClass {
	abstract void abstractMeth();
	public static void main(String [] ar){
		AbstractClass ac = new AbstractClass();
	}
	static void staticabstractMeth();

}
