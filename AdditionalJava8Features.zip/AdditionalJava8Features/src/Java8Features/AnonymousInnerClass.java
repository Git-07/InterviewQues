package Java8Features;

public class AnonymousInnerClass {
	
	//Anonymous inner class is more powerful than lambda expression
	//1.Anonymous inner class can extend a normal class
	//2.Anonymous inner class can extend an abstract class
	//3.Anonymous inner class can implement an interface
	
	
	//But
	//1.Lambda expression can implement an interace which contains a single abstract method
	//Below is Lamda expression way
	public static void main(String[] ar){
		
		Runnable r = () ->{
		
		for(int i =0 ; i < 4 ; i++){
			System.out.println("Thread from Lamda expression number : " + i);
		}
	};
	Thread t = new Thread(r);
	t.start();	
	
	// Below is anonymous inner class way
		Runnable r1 = new Runnable() {			
			public synchronized void run() {
				
				for(int i =0 ; i < 4 ; i++){
					System.out.println("Thread from anonymous inner class number : " + i);
				}
		  }		 
	};
	Thread t1 = new Thread(r1);
	t1.start();
 }
}
