package Java8Features;

import java.util.function.Predicate;


class PredicateTest{
	
	Predicate<Integer> lesser = i -> i < 20;
	Predicate<Integer> greater = i -> i > 20;
	Predicate<Integer> even = i -> i%2 == 0;
	Predicate<Integer> odd = i -> i%2 != 0;
	//Predicate<Integer> square = i -> i*i; // will be taken care by Function Interface import java.util.function.Function
	
	void predCompare(int number , Predicate<Integer> pred){
		
		System.out.println(pred.test(number));	
	}
	
}

class PredicateAndNegate{
	
	
	void predChaining(int number){
		
		Predicate<Integer> lesserThanTwenty = i -> i < 20;
		Predicate<Integer> greaterThanTwenty = i -> i > 20;
		System.out.println(lesserThanTwenty.and(greaterThanTwenty).test(number));
		System.out.println(lesserThanTwenty.and(greaterThanTwenty).negate().test(number));
	}
	
}

class PredicateOR{
	
	
	void predChaining(int number){
		
		Predicate<Integer> lesserThanTwenty = i -> i < 20;
		Predicate<Integer> greaterThanTwenty = i -> i > 20;
		System.out.println(lesserThanTwenty.or(greaterThanTwenty).test(number));
		System.out.println(lesserThanTwenty.or(greaterThanTwenty).negate().test(number));
	}
	
}

public class PredicateFuntionalInterfaceAndMethods {
	
	public static void main(String [] ar){
		
		PredicateTest pt = new PredicateTest();
		System.out.println(pt.lesser.test(10));
		System.out.println(pt.greater.test(10));
		System.out.println(pt.even.test(10));
		System.out.println(pt.odd.test(10));
		pt.predCompare(7, i -> i < 10);
		System.out.println("======================");
		PredicateAndNegate pa = new PredicateAndNegate();
		pa.predChaining(11);
		System.out.println("======================");
		PredicateOR po = new PredicateOR();
		po.predChaining(11);
		
	}

}
