package Java8Features;

import java.util.function.Function;

public class LambdaExpressionMultiplicationFunction {


		
	static int i = 9;
	String s = "Lambda Expression"; 

	static Function<Integer,Integer> mul = i -> i*i;
    	
	public static void main (String [] ar){
		
	System.out.println("The value of Square : " + mul.apply(i));	
		
	}
}
