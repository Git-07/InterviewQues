package Java8Features;

@FunctionalInterface
interface FuncInterf{
	
	public void onlyOneAb();

	
}
@FunctionalInterface
interface FuncInterf2{

	public int arithmeticOperation(int a, int b);

}

public class LambdaExpressionSyntax {
	
	
	public static void main(String [] ar){
		
		System.out.println("The Lamda expression is now being invoked");
		FuncInterf funcInterf =  () -> System.out.println("This is the lambda expression 'void onlyOneAb' called successfully");
		funcInterf.onlyOneAb();
		FuncInterf2 multiply =  (a,b)-> 
		{
			System.out.println("This is the lambda expression 'int onlyOneAb for multipliaction' called successfully");
			return a*b;
		};		
		System.out.println(multiply.arithmeticOperation(2,3));
		FuncInterf2 add = (a,b)-> 
		{
			System.out.println("This is the lambda expression 'int onlyOneAb for addition' called successfully");
			return a + b;
		};
		System.out.println(add.arithmeticOperation(2,3));
		
		FuncInterf2 subtract = (a,b)->
		{
			return a - b;
		};
		System.out.println(subtract.arithmeticOperation(4, 2));
		
	}
    
	//No name, No return type, No modifiers
	
	
	 
/*	 (a,b) -> System.out.println(a+b);
	 
	 (int n) -> n*n; // 
	 (int z) -> {return z*z;}; // becoz here the return type is used thats why {} braces are used
      n -> n*n; // there is no need of () parantheses if only one parameter is available
      s->s.length();
      */
      
      //To Call the lambda expression
      
}

