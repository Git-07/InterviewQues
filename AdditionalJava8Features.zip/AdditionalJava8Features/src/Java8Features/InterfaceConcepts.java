package Java8Features;

public interface InterfaceConcepts {
	static void staticMethJ8();

}
