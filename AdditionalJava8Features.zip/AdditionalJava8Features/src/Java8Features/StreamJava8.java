package Java8Features;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

class StreamOpreations{
	
	List<String> streamTest(){
	List<String> list = new ArrayList<String>();
	list.add("asd");
	list.add("asd");
	list.add("asdf");
	list.add("asdf");
    
	return list;
	}
}
public class StreamJava8 {
	
	public static void main(String [] ar){
		StreamOpreations so = new StreamOpreations();
		List<String> filt = so.streamTest().stream()
		.filter(str -> str.contains("asdf")).collect(Collectors.toList());
		System.out.println(filt);
		System.out.println("===================");
		Stream<String> filtStream = so.streamTest().stream()
				.filter(str -> str.contains("asdf"));
		System.out.println(filtStream.collect(Collectors.toList()));
	}

}
