package Java8Features;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

interface Security{
	int a;

	static void userDetails(){ //Being static, It provides security feature as all the sub classes implementing can't override it 
		
		System.out.println("User name : " + "Mack");
		System.out.println("User PAN : " + "12134ASDF");
	}
	
	static void sortTheList(ArrayList<String> l){ //Being static , it is good for providing utility class methods 
		 
		Collections.sort(l);
		
	}
	default void userSchoolTimings(){
		System.out.println("The schhol timings are from 8 AM to 2.30 PM");
	}
	
	default int hashCode(){ //Compilation Error: A default method cannot override a method from java.lang.Object
			
			return 10;
		}
	
	static void wait(){ // Compilation Error: This static method cannot hide the instance method from Object
		
		
	}
	
	static boolean equals(Object obj){ // Compilation Error: This static method cannot hide the instance method from Object
		
		return true;
	}
	
	abstract void userAcademicsDetails(String schoolOrCollege);
}

 class Base implements Security{

 
	 static void userDetails(){
		
		System.out.println("User name : " + "Mack becomes Jack in Base");
		System.out.println("User PAN : " + "12134ASDF becomes 12222qwein Baser");
		
	}

	@Override
	public void userAcademicsDetails(String schoolOrCollege) {
		// TODO Auto-generated method stub
		
	}
 }
	public class UseOfStaticAndDefaultMethodIn1Dot8 extends Base{	
		
		
		 static void userDetails(){
				
				System.out.println("User name : " + "Mack becomes Jack in child");
				System.out.println("User PAN : " + "12134ASDF becomes 12222qwer in Child");
				
			}
		 
		 @Override
			public void userAcademicsDetails(String schoolOrCollege) {

  System.out.println("the default implemented in Base but overrided in child");
				
			}
		 
		public  void userSchoolTimings(){
				System.out.println("The schhol timings are from 9 AM to 3.30 PM changed in Child class");
			}
	public int hashCode(){
		
		return 0;
	}		
		 
	public static void main(String [] ar){
		
		Security us = new UseOfStaticAndDefaultMethodIn1Dot8();
		UseOfStaticAndDefaultMethodIn1Dot8 us1 = (UseOfStaticAndDefaultMethodIn1Dot8) us;
		us1.userDetails();
		Security.userDetails();
		Security.userDetails();
		us.userSchoolTimings();
		us1.userSchoolTimings();
		us.userAcademicsDetails("Test");
	}

	
	

}
