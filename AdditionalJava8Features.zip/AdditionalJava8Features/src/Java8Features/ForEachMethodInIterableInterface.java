package Java8Features;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ForEachMethodInIterableInterface {

	public static void main(String[] ar){
		
		List<Integer> intar = new ArrayList<Integer>();
		
		for(int i=0 ; i < 10 ; i++){
			intar.add(i);
		}
		
		List<Integer> intar1 = new ArrayList<Integer>();
		
		for(int i=0 ; i < 10 ; i++){
			intar1.add(i);
		}
		
		Iterator<Integer> itr = intar.iterator();
		while(itr.hasNext()){
			
			Integer i = itr.next();
			System.out.println("Integer value " + i);
			
		}
		
	   intar.forEach((n) -> 
	   {
		   System.out.println(n);
	   });
		
	}
}
