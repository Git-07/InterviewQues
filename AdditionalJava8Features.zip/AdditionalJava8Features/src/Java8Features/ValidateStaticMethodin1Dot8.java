package Java8Features;


interface interf5 {
	
	public static void test(){
		
	}

}
public class ValidateStaticMethodin1Dot8 {

}
