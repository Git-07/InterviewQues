package Java8Features;

interface Interf{
	
	public void method1();
	public void method2();
	default void implementedMethod(){
		System.out.println("Default method1 implemented in Interf1");
	}
	
	//on using a default method from Object class	
	//A default method cannot override a method from java.lang.Object
   default int hashCode(){
		
		return 10;
	}
	static void staticMethod(){
		
		System.out.println("staticMethod in interf1");
	}
	
	
}

interface Interf3 extends Interf {
	

	default void implementedMethod(){
		System.out.println("Default method implemented in Interf3");
	}
	static void staticMethod(){
		
		System.out.println("staticMethod in interf2");
	}
	
}

interface Interf2 {
	
	default void implementedMethod(){
		System.out.println("Default method implemented in Interf2");
	}
	static void staticMethod(){
		
		System.out.println("staticMethod in interf2");
	}
	
}
public class DefaultMethodIn1Dot8 implements Interf,Interf2 {
	
	//Default method should not come in class, it should be public becoz in class default has another meaning
	default void defMethod(){
			
	}
	public void implementedMethod(){
		
		Interf.super.implementedMethod();
		System.out.println("Default method overrided");
		
	 } 
	
	 public void staticMethod(){
		 Interf.staticMethod();
		 Interf2.staticMethod();
		 System.out.println("static method overrided");
	 }
	public void method1(){
		System.out.println("Implemented method1");
		
	}
	public void method2(){
		
		System.out.println("Implemented method2");
	}
	
	public static void main(String[] ar){
		
		DefaultMethodIn1Dot8 obj = new DefaultMethodIn1Dot8();
		obj.staticMethod();
		obj.implementedMethod();
		obj.method1();
		obj.method2();	    
	}
}
